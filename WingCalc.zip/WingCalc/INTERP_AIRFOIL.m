perf = 'NACA 23024';
pts = load(strcat(['PERFILES SIN CAMBIAR\' perf '.txt']));
% pts = pts/1000;
xairf = pts(:,1);
yairf = pts(:,2);

pos = find(min(xairf)==xairf);
yairf1 = interp1(xairf(1:pos),yairf(1:pos),0:0.01:1);
yairf2 = interp1(xairf(pos:end),yairf(pos:end),.01:0.01:1);

xairf = [flip(0:0.01:1) .01:0.01:1];
yairf = [flip(yairf1) yairf2];

plot(xairf,yairf)
daspect([1 1 1])
hold on
plot(pts(:,1),pts(:,2))

pts2 = [xairf' yairf'];
open pts2

save(strcat(['PERFILES\' perf '.txt']),'pts2')
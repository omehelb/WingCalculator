
load ('..\MATLAB\data.mat','data')

data.Figure.Position    = [507,250,874,513];

data.Dimensiones.Esbeltez       = 9.42;
data.Dimensiones.Estrechamiento = 0.26;
data.Dimensiones.FlechaLE       = 27.49;
data.Dimensiones.FNegativa      = false;
data.Dimensiones.Diedro         = 4.57;
data.Dimensiones.Torsion        = 10;
data.Dimensiones.CuerdaRaiz     = 5.73;
data.Dimensiones.Envergadura    = (1+.26)*5.73*9.42/2;
data.Dimensiones.EspesorPiel    = 4;
data.Dimensiones.Perfil         = 'NACA 2412';

data.Interior.NumeroCostillas           = 15;
data.Interior.EspesorCostillas          = 4;
data.Interior.PosicionLarguero1         = .15;
data.Interior.PosicionLarguero2         = .6;
data.Interior.EspesorLarguero1          = 3;
data.Interior.EspesorLarguero2          = 4;
data.Interior.PosicionMotorEnvergadura  = .4;
data.Interior.PosicionMotorCuerda       = .2;
data.Interior.PesoMotor                 = 1200;
data.Interior.PorcentajeConbustible     = .5;

data.Materiales.MaterialCostillas = 'Al-Zn DTD 5114';
data.Materiales.MaterialLargueros = 'Al-Cu L168    ';
data.Materiales.MaterialPiel      = 'Ti-6Al-4V     ';

data.Refuerzos.Cordones.Existentes = false;
data.Refuerzos.Cordones.Delantero_Superior = 0;
data.Refuerzos.Cordones.Delantero_Inferior = 0;
data.Refuerzos.Cordones.Posterior_Superior = 0;
data.Refuerzos.Cordones.Posterior_Inferior = 0;

data.Refuerzos.Larguerillos.Acoplados = true;
data.Refuerzos.Larguerillos.Inexistentes = false;
data.Refuerzos.Larguerillos.Forma = 'Perfil Z       ';
data.Refuerzos.Larguerillos.Proporcion = 2.1;
data.Refuerzos.Larguerillos.NumeroLarguerillos = 30;
data.Refuerzos.Larguerillos.Espesor = 20;
data.Refuerzos.Larguerillos.Material  = 'Al-Zn DTD 5114';

data.Aerodinamica.Velocidad         = 80;
data.Aerodinamica.AoA               = 3;
data.Aerodinamica.VariableDensidad  = false;
data.Aerodinamica.Temperatura       = 285;
data.Aerodinamica.Altitud           = 15000;
data.Aerodinamica.Densidad          = .4127;

save('..\MATLAB\data.mat',"data")
function VLM_data(data)

[xmesh,ymesh,zmesh] = VLM_mesh;

xmeshv = xmesh(:,:,1);
ymeshv = ymesh(:,:,1);
zmeshv = zmesh(:,:,1);

xmeshc = xmesh(:,:,2);
ymeshc = ymesh(:,:,2);
zmeshc = zmesh(:,:,2);


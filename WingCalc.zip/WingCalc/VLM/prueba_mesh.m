clear
load('..\data.mat')

crw = data.Dimensiones.CuerdaRaiz;
ARw = data.Dimensiones.Esbeltez;
law = data.Dimensiones.Estrechamiento;
LLE = data.Dimensiones.FlechaLE*pi/180;
Did = data.Dimensiones.Diedro*pi/180;
tor = data.Dimensiones.Torsion*pi/180;

per = data.Dimensiones.Perfil;

nco = data.Interior.NumeroCostillas;


% Se calcula la semienvergadura ya que el ala es simétrica en x=0.
sbw = (1+law)*ARw*crw/4;

% Se crean las variables "x" e "y" de forma que se forme un ala plana
[xmesh0,~] = meshgrid(linspace(0,sbw,2*nco-1),1:49);
[~,ymesh0] = meshgrid(1:2*(nco-1),linspace(0,crw,50));

% Ángulo al establecer estrechamiento
ang       = atan2((1 - law)*crw/2,sbw);

% Vector de puntos en la dirección x
xsbw      = linspace(0,sbw,2*nco-1);
xsbw      = (xsbw(1:end-1)+xsbw(2:end))/2;

% Factor de estrechamiento
lawx      = ones(50,1)*((law - 1)/sbw*xsbw+1);

% Añadiendo estrechamiento y flecha en la dirección "y"
ymesh0    = (ymesh0 - .5*crw).*lawx + ones(50,1)*xsbw*tan(LLE - ang);

% Se añaden la linea de curvatura a las alturas.
zmesh0 = zeros(size(ymesh0));
perfil = load(['..\PERFILES\ChamberLine\' per '.txt'])*crw;
zmesh0 = zmesh0 + perfil(:,2);

% Vector de torsión
torvev = tor/sbw*linspace(0,sbw,2*(nco-1));

% Cuarto de panel
cpanel = crw/49;

xmesh1 = (xmesh0(:,1:end-1)+xmesh0(:,2:end))/2;
ymesh1 = ymesh0.*(ones(50,1)*cos(torvev)) - zmesh0.*(ones(50,1)*sin(torvev));
zmesh1 = zmesh0.*(ones(50,1)*cos(torvev)) + ymesh0.*(ones(50,1)*sin(torvev));

zmesh1 = zmesh1 + ones(50,1)*xsbw*tan(Did);
zmesh1 = zmesh1(1:end-1,:);

ymesh1 = ymesh1(1:end-1,:) + cpanel/4;

xmesh1 = [-flip(xmesh1')' xmesh1];
ymesh1 = [ flip(ymesh1')' ymesh1];
zmesh1 = [ flip(zmesh1')' zmesh1];

plot3(xmesh1,ymesh1,zmesh1,'k.')
daspect([1 1 1])
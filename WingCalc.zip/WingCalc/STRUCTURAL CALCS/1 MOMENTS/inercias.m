function data = inercias(data)
% Importar datos de posición z de espesor ---------------------------------
perf = data.Dimensiones.Perfil;
plr1 = data.Interior.PosicionLarguero1;
plr2 = data.Interior.PosicionLarguero2;

tskn = data.Dimensiones.EspesorPiel/1000;
tcos = data.Interior.EspesorCostillas/1000;
tlr1 = data.Interior.EspesorLarguero1/1000;
tlr2 = data.Interior.EspesorLarguero2/1000;
crw  = data.Dimensiones.CuerdaRaiz;


% Imporar el perfil -------------------------------------------------------
ptos = load(['PERFILES\' perf '.txt']);

ptos1 = ptos(1:101,:);
ptos2 = ptos(101:end,:);


% Aumentar resolución el perfil -------------------------------------------
ypts2 = (0:5e-4:1)';
ypts1 = flip(ypts2);

zpts1 = interp1(ptos1(:,1),ptos1(:,2),ypts1,'spline');
zpts2 = interp1(ptos2(:,1),ptos2(:,2),ypts2,'spline');

ypts  = [ypts1(1:end-1); ypts2]*crw;
zpts  = [zpts1(1:end-1); zpts2]*crw;


% Calcular puntos medios z distancias -------------------------------------
yptsi = ypts(1:end-1);
yptsf = ypts(2:end);
yptsm = mean([yptsi,yptsf]')';

zptsi = zpts(1:end-1);
zptsf = zpts(2:end);
zptsm = mean([zptsi,zptsf]')';

longp = sqrt(diff(ypts).^2 + diff(zpts).^2);


% Añadir largueros --------------------------------------------------------
plr1y = floor(100*plr1)/100;
plr2y = floor(100*plr2)/100;

psl1z1 = find(plr1y == ptos1(:,1));
psl1z2 = find(plr1y == ptos2(:,1));

psl2z1 = find(plr2y == ptos1(:,1));
psl2z2 = find(plr2y == ptos2(:,1));

pl1y   = [plr1y; plr1y]*crw;
pl1z   = [ptos1(psl1z1,2); ptos2(psl1z2,2)]*crw;
pl2y   = [plr2y; plr2y]*crw;
pl2z   = [ptos1(psl2z1,2); ptos2(psl2z2,2)]*crw;

dpl1   = abs(diff(pl1z));
dpl2   = abs(diff(pl2z));


% Vectores de espesores ---------------------------------------------------
tp = tskn*ones(size(yptsi));
tc = tcos*ones(size(yptsi));


% Cordones de los largueros -----------------------------------------------
A_DS = data.Refuerzos.Cordones.Delantero_Superior;
A_DI = data.Refuerzos.Cordones.Delantero_Inferior;
A_PS = data.Refuerzos.Cordones.Posterior_Superior;
A_PI = data.Refuerzos.Cordones.Posterior_Inferior;

P_DS = [plr1 ptos1(psl1z1,2)]*crw;
P_DI = [plr1 ptos2(psl1z2,2)]*crw;
P_PS = [plr2 ptos1(psl2z1,2)]*crw;
P_PI = [plr2 ptos2(psl2z2,2)]*crw;

P_cory = [P_DS(1); P_DI(1); P_PS(1); P_PI(1)];
P_corz = [P_DS(2); P_DI(2); P_PS(2); P_PI(2)];

% Larguerillos ------------------------------------------------------------
larguerillo = data.Refuerzos.Larguerillos.Forma;

if logical(prod(larguerillo == 'Perfil Z       '))
    perfy = [-1 -1 0 0 1 1];
    perfz = [-.75 -1 -1 1 1 .75];
    yGlargi = 1;
    zGlargi = -1;
elseif logical(prod(larguerillo == 'Perfil J       '))
    perfy = [-1 -1 0 0 -1 1];
    perfz = [-.75 -1 -1 1 1 1];
    yGlargi = .8571;
    zGlargi = -.8512;
elseif logical(prod(larguerillo == 'Perfil sombrero'))
    perfy = [-1 -.5 -.5 .5 .5 1];
    perfz = [1 1 -1 -1 1 1];
    yGlargi = 1;
    zGlargi = -1;
elseif logical(prod(larguerillo == 'Perfil I       '))
    perfy = [-1 1 0 0 -1 1];
    perfz = [-1 -1 -1 1 1 1];
    yGlargi = 1;
    zGlargi = -1;
elseif logical(prod(larguerillo == 'Perfil Y       '))
    perfy = [-1 -.5 0 0 -.33 .33 0 0 .5 1];
    perfz = [1 1 0 -1 -1 -1 -1 0 1 1];
    yGlargi = 1;
    zGlargi = -.8043;
end
prop  = data.Refuerzos.Larguerillos.Proporcion;
nlarg = data.Refuerzos.Larguerillos.NumeroLarguerillos;

espacio = (plr2 - plr1)*crw;
ylarg = (perfy + 1)*espacio/(2*nlarg);
zlarg = (perfz + 1)*espacio/(2*nlarg)*prop;

yGlargi = yGlargi*espacio/(2*nlarg);
zGlargi = yGlargi*espacio/(2*nlarg)*prop;

inicialya = plr1*crw;
inicialza = mean([pl1z(1),pl2z(1)]);

inicialyb = plr1*crw;
inicialzb = mean([pl1z(2),pl2z(2)]);

yGlargi1 =  yGlargi + inicialya;
zGlargi1 =  zGlargi + inicialza;

yGlargi2 =  yGlargi + inicialyb;
zGlargi2 = -zGlargi + inicialzb;

yGlrgss = linspace(yGlargi1, yGlargi1 + (nlarg-1)*espacio/(nlarg),nlarg)';
zGlrgss = zGlargi1*ones(size(yGlrgss));

yGlrgsi = linspace(yGlargi2, yGlargi2 + (nlarg-1)*espacio/(nlarg),nlarg)';
zGlrgsi = zGlargi2*ones(size(yGlrgsi));

yGlrgs = [yGlrgss; yGlrgsi];
zGlrgs = [zGlrgss; zGlrgsi];

if data.Refuerzos.Larguerillos.Acoplados == 1
    larguerillo = data.Refuerzos.Larguerillos.Forma;

    if logical(prod(larguerillo == 'Perfil Z       '))
        Alargi  = (1 + 1.25*prop);
    elseif logical(prod(larguerillo == 'Perfil J       '))
        Alargi  = (1.5 + 1.125*prop);
    elseif logical(prod(larguerillo == 'Perfil sombrero'))
        Alargi  = (1 + 2*prop);
    elseif logical(prod(larguerillo == 'Perfil I       '))
        Alargi  = (2 + 1*prop);
    elseif logical(prod(larguerillo == 'Perfil Y       '))
        Alargi  = (.833 + .5*prop + 2*sqrt(.25^2+(.5*prop)^2));
    end
    tprop = data.Refuerzos.Larguerillos.Espesor;
    nlarg = data.Refuerzos.Larguerillos.NumeroLarguerillos;

    espacio = (plr2 - plr1)*crw;
    tlarg = 1/tprop*espacio/nlarg;

    Alarg   = tlarg*Alargi*(espacio/nlarg);
else
    Alarg   = 0;
end


% Completar todos los vectores de los largueros ---------------------------
yptsli = [plr1y; plr2y]*crw;
yptslf = [plr1y; plr2y]*crw;
yptslm = [plr1y; plr2y]*crw;

zptsli = [pl1z(1);    pl2z(1)];
zptslf = [pl1z(2);    pl2z(2)];
zptslm = [mean(pl1z); mean(pl2z)];

tl = [tlr1; tlr2];

longpl = [dpl1; dpl2];


% Centro de graverdad -----------------------------------------------------
Atp   = longp.*tp;                      ATp   = sum(Atp);
Atl   = longpl.*tl;                     ATl   = sum(Atl);
Atcor = [A_DS;A_DI;A_PS;A_PI];          ATcor = sum(Atcor(:,1)) + 1e-16;
Atlar = Alarg;                          ATlar = Atlar*2*nlarg + 1e-16;

yGp   = sum(Atp.*yptsm)/ATp;            zGp   = sum(Atp.*zptsm)/ATp;
yGl   = sum(Atl.*yptslm)/ATl;           zGl   = sum(Atl.*zptslm)/ATl;
yGcor = sum(Atcor(:,1).*P_cory)/ATcor;  zGcor = sum(Atcor(:,1).*P_corz)/ATcor;
yGlar = sum(Atlar.*yGlrgs)/ATlar;       zGlar = sum(Alarg.*zGlrgs)/ATlar;

yG = (yGp*ATp + yGl*ATl + yGcor*ATcor + yGlar*ATlar)/...
    (ATp + ATl + ATcor + ATlar);

zG = (zGp*ATp + zGl*ATl + zGcor*ATcor + zGlar*ATlar)/...
    (ATp + ATl + ATcor + ATlar);


% Ajustar el perfil al centro de gravedad ---------------------------------
yip   = yptsi - yG;           yic = yptsi - yG;
yfp   = yptsf - yG;           yfc = yptsf - yG;
ymp   = yptsm - yG;           ymc = yptsm - yG;

zip   = zptsi - zG;           zic = zptsi - zG;
zfp   = zptsf - zG;           zfc = zptsf - zG;
zmp   = zptsm - zG;           zmc = zptsm - zG;


% Ajustar el larguero al centro de gravedad -------------------------------
yil   = yptsli - yG;          zil = zptsli - zG;
yfl   = yptslf - yG;          zfl = zptslf - zG;
yml   = yptslm - yG;          zml = zptslm - zG;


% Ajustar los cordones al centro de gravedad ------------------------------
P_cory = P_cory - yG;
P_corz = P_corz - zG;


% Ajustar los larguerillos al centro de gravedad --------------------------
yGlrgs = yGlrgs - yG;
zGlrgs = zGlrgs - zG;

%% CALCULAR INERCIAS ------------------------------------------------------
x   = data.Esfuerzos.Diagramas.x';
sbw = data.Dimensiones.Envergadura/2;
nco = data.Interior.NumeroCostillas;

ARw = data.Dimensiones.Esbeltez;
law = data.Dimensiones.Estrechamiento;
tor = data.Dimensiones.Torsion*pi/180;

xc   = linspace(0,sbw,nco)';
posc = zeros(size(xc));

% Puntos de la envergadura con costilla -----------------------------------
for i = 1:length(xc)
    psc     = find(xc(i)>=x);
    posc(i) = psc(end);
end

posc = unique(posc);

% Ineria de costilla, larguero y piel -------------------------------------
Iyc  = zeros(size(x));
Izc  = zeros(size(x));
Iyzc = zeros(size(x));

Iy  = zeros(size(x));
Iz  = zeros(size(x));
Iyz = zeros(size(x));

Iyl  = zeros(size(x));
Izl  = zeros(size(x));
Iyzl = zeros(size(x));

% Calculo de inercias rotando el perfil con el método de Simpson ----------
for i = 1:length(x)
    lw = (law-1)/sbw*x(i) + 1;
    tw = -tor/sbw*x(i);
    
    iyp = cos(tw)*yip - sin(tw)*zip;
    izp = sin(tw)*yip + cos(tw)*zip; 
    
    fyp = cos(tw)*yfp - sin(tw)*zfp;
    fzp = sin(tw)*yfp + cos(tw)*zfp;
    
    myp = cos(tw)*ymp - sin(tw)*zmp;
    mzp = sin(tw)*ymp + cos(tw)*zmp;
    
    iyc = cos(tw)*yic - sin(tw)*zic;
    izc = sin(tw)*yic + cos(tw)*zic;
    
    fyc = cos(tw)*yfc - sin(tw)*zfc;
    fzc = sin(tw)*yfc + cos(tw)*zfc;
    
    myc = cos(tw)*ymc - sin(tw)*zmc;
    mzc = sin(tw)*ymc + cos(tw)*zmc;
    
    iyl = cos(tw)*yil - sin(tw)*zil;
    izl = sin(tw)*yil + cos(tw)*zil;
    
    fyl = cos(tw)*yfl - sin(tw)*zfl;
    fzl = sin(tw)*yfl + cos(tw)*zfl;
    
    myl = cos(tw)*yml - sin(tw)*zml;
    mzl = sin(tw)*yml + cos(tw)*zml;

    if ismember(i,posc)
        Iyc(i)  = sum(lw^2*tc.*longp/6.*(izc.^2 + fzc.^2 + 4*mzc.^2));
        Izc(i)  = sum(lw^2*tc.*longp/6.*(iyc.^2 + fyc.^2 + 4*myc.^2));
        Iyzc(i) = sum(lw^2*tc.*longp/6.*(izc.*iyc + fzc.*fyc + 4*mzc.*myc));
    end
    Iy(i)  = sum(lw^2*Atp/6.*(izp.^2 + fzp.^2 + 4*mzp.^2));
    Iz(i)  = sum(lw^2*Atp/6.*(iyp.^2 + fyp.^2 + 4*myp.^2));
    Iyz(i) = sum(lw^2*Atp/6.*(izp.*iyp + fzp.*fyp + 4*mzp.*myp));

    Iyl(i)  = sum(lw^2*Atl/6.*(izl.^2 + fzl.^2 + 4*mzl.^2));
    Izl(i)  = sum(lw^2*Atl/6.*(iyl.^2 + fyl.^2 + 4*myl.^2));
    Iyzl(i) = sum(lw^2*Atl/6.*(izl.*iyl + fzl.*fyl + 4*mzl.*myl));
end

% Inercias de los cordones ------------------------------------------------
for i = 1:length(x)
    lw = (law-1)/sbw*x(i) + 1;  
    tw = -tor/sbw*x(i);

    ycor = lw*(cos(tw)*P_cory - sin(tw)*P_corz);
    zcor = lw*(sin(tw)*P_cory + cos(tw)*P_corz);

    acor = Atcor(:,i);

    Iycor(i)  = sum(acor.*zcor.^2);

    Izcor(i)  = sum(acor.*ycor.^2);

    Iyzcor(i) = sum(acor.*zcor.*ycor);
end


% Inercias de los larguerillos --------------------------------------------
if data.Refuerzos.Larguerillos.Acoplados == true
    [Iylarg,Izlarg,Iyzlarg] = inercias_larguerillos(data,yGlrgs,zGlrgs);
else
    Iylarg  = 0;
    Izlarg  = 0;
    Iyzlarg = 0;
end

% Recoger datos -----------------------------------------------------------

data.Esfuerzos.Inercias.Piel.Iy  = Iy';
data.Esfuerzos.Inercias.Piel.Iz  = Iz';
data.Esfuerzos.Inercias.Piel.Iyz = Iyz';
data.Esfuerzos.Inercias.Piel.Id  = (Iy.*Iz - Iyz.^2)';

Iy  = Iy  + Iyc  + Iyl  + Iycor'  + Iylarg';
Iz  = Iz  + Izc  + Izl  + Izcor'  + Izlarg';
Iyz = Iyz + Iyzc + Iyzl + Iyzcor' + Iyzlarg';

Id  = Iy.*Iz - Iyz.^2;

data.Esfuerzos.Inercias.Totales.Iy  = Iy';
data.Esfuerzos.Inercias.Totales.Iz  = Iz';
data.Esfuerzos.Inercias.Totales.Iyz = Iyz';
data.Esfuerzos.Inercias.Totales.Id  = Id';

data.Esfuerzos.Inercias.Costillas.Iyc  = Iyc';
data.Esfuerzos.Inercias.Costillas.Izc  = Izc';
data.Esfuerzos.Inercias.Costillas.Iyzc = Iyzc';
data.Esfuerzos.Inercias.Costillas.Id  = (Iyc.*Izc - Iyzc.^2)';

data.Esfuerzos.Inercias.Largueros.Iy  = Iyl';
data.Esfuerzos.Inercias.Largueros.Iz  = Izl';
data.Esfuerzos.Inercias.Largueros.Iyz = Iyzl';
data.Esfuerzos.Inercias.Largueros.Id  = (Iyl.*Izl - Iyzl.^2)';

data.Esfuerzos.Inercias.Larguerillos.Iy  = Iylarg;
data.Esfuerzos.Inercias.Larguerillos.Iz  = Izlarg;
data.Esfuerzos.Inercias.Larguerillos.Iyz = Iyzlarg;
data.Esfuerzos.Inercias.Larguerillos.Id  = (Iylarg.*Izlarg - Iyzlarg.^2)';

data.Esfuerzos.Inercias.Cordones.Iy  = Iycor;
data.Esfuerzos.Inercias.Cordones.Iz  = Izcor;
data.Esfuerzos.Inercias.Cordones.Iyz = Iyzcor;
data.Esfuerzos.Inercias.Cordones.Id  = (Iycor.*Izc - Iyzcor.^2);

data.Esfuerzos.Centro_de_Gravedad.Y = yG;
data.Esfuerzos.Centro_de_Gravedad.Z = zG;


save('saveddata.mat','data');
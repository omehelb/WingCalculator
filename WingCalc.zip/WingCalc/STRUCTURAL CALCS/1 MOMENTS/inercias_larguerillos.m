function [Iylarg,Izlarg,Iyzlarg] = inercias_larguerillos(data,yGlrgs,zGlrgs)

larguerillo = data.Refuerzos.Larguerillos.Forma;
plr1        = data.Interior.PosicionLarguero1;
plr2        = data.Interior.PosicionLarguero2;
crw         = data.Dimensiones.CuerdaRaiz;
prop        = data.Refuerzos.Larguerillos.Proporcion;
nlarg       = data.Refuerzos.Larguerillos.NumeroLarguerillos;
x           = data.Esfuerzos.Diagramas.x';
law         = data.Dimensiones.Estrechamiento;
tor         = data.Dimensiones.Torsion*pi/180;
sbw         = data.Dimensiones.Envergadura/2;

espacio     = abs(plr2 - plr1)*crw;
q           = espacio/nlarg;

if logical(prod(larguerillo == 'Perfil Z       '))
    perfy = [-.5 -.5;-.5 0;0 0;0 .5;.5 .5]'*q;
    perfz = [-.375 -.5;-.5 -.5;-.5 .5;.5 .5;.5 .375]'*prop*q;
    yGli = 0;
    zGli = 0;
elseif logical(prod(larguerillo == 'Perfil J       '))
    perfy = [-.5 -.5;-.5 0;0 0;-.5 .5]'*q;
    perfz = [-.375 -.5;-.5 -.5;-.5 .5;.5 .5]'*prop*q;
    yGli = -0.0715*q;
    zGli =  0.0744*q;
elseif logical(prod(larguerillo == 'Perfil sombrero'))
    perfy = [-.5 -.25;-.25 -.25;-.25 .25;.25 .25;.25 .5]'*q;
    perfz = [.5 .5;.5 -.5;-.5 -.5;-.5 .5;.5 .5]'*prop*q;
    yGli = 0;
    zGli = 0;
elseif logical(prod(larguerillo == 'Perfil I       '))
    perfy = [-.5 .5;0 0;-.5 .5]'*q;
    perfz = [.5 .5;.5 -.5;-.5 -.5]'*prop*q;
    yGli = 0;
    zGli = 0;
elseif logical(prod(larguerillo == 'Perfil Y       '))
    perfy = [-.5 -.25;-.25 0;0 .25;.25 .5;0 0;-.33 .33]'*q;
    perfz = [.5 .5;.5 0;0 .5;.5 .5;0 -.5;-.5 -.5]'*prop*q;
    yGli = 0;
    zGli = 0.0978*q;
end

tprop = data.Refuerzos.Larguerillos.Espesor;
tlarg = q/tprop;

long = sqrt(diff(perfy).^2 + diff(perfz).^2);
yGi  = mean(perfy);
zGi  = mean(perfz);

Iyi      = sum(abs(diff(perfz)).^3*tlarg/12 + long*tlarg.*(zGi - zGli).^2);
Izi      = sum(abs(diff(perfy)).^3*tlarg/12 + long*tlarg.*(yGi - yGli).^2);
Iyzi_in  = sum(long*tlarg.*(zGi - zGli).*(yGi - yGli));
Iyzi_su  = sum(long*tlarg.*(-zGi - zGli).*(yGi - yGli));

Alarg    = sum(long*tlarg);

for i = 1:length(x)
    lw = (law-1)/sbw*x(i) + 1;
    tw = -tor/sbw*x(i);
    
    Iy1  = sum(lw^4*(2*nlarg*Iyi + Alarg*zGlrgs.^2));
    Iz1  = sum(lw^4*(2*nlarg*Izi + Alarg*yGlrgs.^2));
    Iyz1 = sum(lw^4*(nlarg*Iyzi_su + nlarg*Iyzi_in + Alarg*zGlrgs.*yGlrgs));

    Iylarg(i)  = Iy1*cos(tw)^2 + Iz1*sin(tw)^2 + Iyz1*sin(tw)*cos(tw);
    Izlarg(i)  = Iy1*sin(tw)^2 + Iz1*cos(tw)^2 - Iyz1*sin(tw)*cos(tw);
    Iyzlarg(i) = (Iz1 - Iy1)*sin(tw)*cos(tw) + Iyz1*(cos(tw)^2 - sin(tw)^2);
end
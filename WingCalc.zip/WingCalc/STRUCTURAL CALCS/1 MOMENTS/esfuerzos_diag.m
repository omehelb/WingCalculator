function [data] = esfuerzos_diag(data)

% Desgranar la variable estructural ---------------------------------------
C_lift = data.Aerodinamica.Coeficientes.CL;
C_lift = C_lift(end/2+1:end);
C_drag = data.Aerodinamica.Coeficientes.CD;
C_drag = C_drag(end/2+1:end);

law   = data.Interior.Estrechamiento_Nuevo;
crw   = data.Interior.CuerdaRaiz_Nueva;
sbw   = data.Interior.Envergadura_Nueva;
per   = data.Dimensiones.Perfil;
Dd    = data.Dimensiones.Diedro*pi/180;
angle = data.Interior.Orientacion;

pl1 = data.Interior.PosicionLarguero1;
pl2 = data.Interior.PosicionLarguero2;

fuelx = data.Interior.PorcentajeCombustible;
enW   = data.Interior.PesoMotor*9.81;

d1 = data.Interior.BA_Motor;
d2 = data.Interior.BF_Motor;


% Aumentar resolución -----------------------------------------------------
xo  = linspace(0,sbw,length(C_lift));
x   = linspace(0,sbw,1000);
dx  = x(2) - x(1);

C_lift = interp1(xo,C_lift,x,'spline');
C_drag = interp1(xo,C_drag,x,'spline');


% Definir ejes coordenados y variación de la cuerda -----------------------
cw = (law - 1)*crw/sbw*x + crw;


% Obtener presión dinámica ------------------------------------------------
vel = data.Aerodinamica.Velocidad;
xrh = data.Aerodinamica.VariableDensidad;
AoA = data.Aerodinamica.AoA*pi/180;

if xrh == true
    rho = data.Aerodinamica.Densidad;
else
    zalt = data.Aerodinamica.Altitud;
    [~,~,~,rho] = atmosisa(zalt);
end

q0 = 1/2*rho*vel^2;


% Obtener distribución de fuerzas -----------------------------------------
Fza = -(C_lift*q0.*cw*cos(AoA) + C_drag*q0.*cw*sin(AoA));
Fya = -(C_drag*q0.*cw*cos(AoA) - C_lift*q0.*cw*sin(AoA));

Fs = [cos(Dd) 0 sin(Dd);0 1 0;-sin(Dd) 0 cos(Dd)]*...
     [cos(angle) -sin(angle) 0;sin(angle) cos(angle) 0;0 0 1]*...
     [zeros(size(Fya)); Fya; Fza];

Fx =  Fs(1,:);
Fy =  Fs(2,:);
Fz =  Fs(3,:);

% Obtener la carga ejercida por el combustible ----------------------------
ptos = load(['PERFILES\' per '.txt']);
pl1 = floor(pl1*100)/100;
pl2 = floor(pl2*100)/100;

ps11 = find(pl1==ptos(1:101,1));
ps12 = find(pl1==ptos(101:end,1)) + 100;

ps21 = find(pl2==ptos(1:101,1));
ps22 = find(pl2==ptos(101:end,1)) + 100;

ACT  = polyarea([ptos(ps21:ps11,1);ptos(ps12:ps22,1)]*crw,...
                [ptos(ps21:ps11,2);ptos(ps12:ps22,2)]*crw);

xfuel = 0:dx:(fuelx*sbw);

lwfuel = (1-law)*xfuel/sbw + 1;

q_fuel = ACT*lwfuel.^2*800*9.81;
qfuel = [q_fuel zeros(1,length(x)-length(q_fuel))];

qfuelx = qfuel*sin(Dd);
qfuelz = qfuel*cos(Dd);


% Descomponer componentes del motor ---------------------------------------
n_perf = length(x);

rel_d1 = d1/sbw;
rel_d2 = d2/sbw;

pos_d1 = min(max(1,floor(rel_d1*n_perf)),n_perf-1);
pos_d2 = max(1,floor(rel_d2*n_perf));

pos_d  = abs(pos_d2 - pos_d1) + 1;
enW_q  = zeros(1,n_perf);
enW_q(sort(pos_d1:pos_d2)) = enW/pos_d;

enWx = enW_q*sin(Dd);
enWz = enW_q*cos(Dd);



% Reacciones --------------------------------------------------------------
AZ = -sum(Fz*dx) - sum(qfuelz*dx) - sum(enWz);
AY = -sum(Fy*dx);

MY = -sum(Fz*dx).*sum(Fz.*x)/sum(Fz) - ...
    sum(qfuelz*dx).*sum(qfuelz.*x)/sum(qfuelz) - ...
    sum(enWz*dx).*sum(enWz.*x)/(sum(enWz) + 1e-7);

MZ = -sum(Fy*dx).*sum(Fy.*x)/sum(Fy);

NX = -sum(Fx*dx) - sum(qfuelx*dx);

if isnan(MZ) == true
    MZ = 0;
end

if isnan(MY) == true
    MY = 0;
end


% Distribución de cortante ------------------------------------------------
Qz = cumsum(Fz*dx) + AZ + cumsum(qfuelz*dx) + cumsum(enWz);
Qy = cumsum(Fy*dx) + AY;


% Distribución de momento -------------------------------------------------
My = cumsum(Qz*dx) - MY;
Mz = -cumsum(Qy*dx) + MZ;
My = My - My(end);


% Distribución de axil ----------------------------------------------------
Nx = cumsum(Fx*dx) + NX + cumsum(qfuelx*dx) + cumsum(enWx);
Nx = Nx - Nx(end);


% Guardar variables -------------------------------------------------------
data.Esfuerzos.Diagramas.x  = x;
data.Esfuerzos.Diagramas.Mz = Mz;
data.Esfuerzos.Diagramas.My = My;
data.Esfuerzos.Diagramas.Qz = Qz;
data.Esfuerzos.Diagramas.Qy = Qy;
data.Esfuerzos.Diagramas.Nx = Nx;
data.Esfuerzos.Diagramas.Fz = Fz;
data.Esfuerzos.Diagramas.Fy = Fy;
data.Esfuerzos.Diagramas.W  = enW_q;

save('saveddata.mat','data');
function data = tension_normal(data)

% Importarlos datos del perfil --------------------------------------------
per = data.Dimensiones.Perfil;
pl1 = data.Interior.PosicionLarguero1;
pl2 = data.Interior.PosicionLarguero2;
crw = data.Dimensiones.CuerdaRaiz;
law = data.Dimensiones.Estrechamiento;
tor = data.Dimensiones.Torsion*pi/180;
sbw = data.Dimensiones.Envergadura;
yG  = data.Esfuerzos.Centro_de_Gravedad.Y;
zG  = data.Esfuerzos.Centro_de_Gravedad.Z;
x   = data.Esfuerzos.Diagramas.x;

tskn = data.Dimensiones.EspesorPiel/1000;
tlr1 = data.Interior.EspesorLarguero1/1000;
tlr2 = data.Interior.EspesorLarguero2/1000;

% Ajustar la posición de los largueros al formato 0.00 --------------------
pl1 = floor(100*pl1)/100;
pl2 = floor(100*pl2)/100;

% Importar datos del perfil y separar en extradós y entrados --------------
ptos  = load(['PERFILES\' per '.txt']);
ptos1 = ptos(1:101,:);
ptos2 = ptos(101:end,:);

% Posición vertical de los largueros --------------------------------------
psl11 = find(pl1==ptos1(:,1));
psl12 = find(pl1==ptos2(:,1));

psl21 = find(pl2==ptos1(:,1));
psl22 = find(pl2==ptos2(:,1));

% Aumentar la resolución del perfil ---------------------------------------
ypin  = linspace(0,1,100)';
ypex  = flip(ypin);

zpex  = interp1(ptos1(:,1),ptos1(:,2),ypex,'spline');
zpin  = interp1(ptos2(:,1),ptos2(:,2),ypin,'spline');

ypr = [ypex; ypin]*crw - yG;
zpr = [zpex; zpin]*crw - zG;


% Aumentar la resolución de los largueros ---------------------------------
yl1 = pl1*ones(100,1)*crw - yG;
zl1 = linspace(ptos1(psl11,2),ptos2(psl12,2),100)'*crw - zG;

yl2 = pl2*ones(100,1)*crw - yG;
zl2 = linspace(ptos1(psl21,2),ptos2(psl22,2),100)'*crw - zG;


% Area total --------------------------------------------------------------
longitudes1 = sqrt(diff(ypr).^2 + diff(zpr).^2);
longitudes2 = sqrt(diff(yl1).^2 + diff(zl1).^2);
longitudes3 = sqrt(diff(yl2).^2 + diff(zl2).^2);

lws = (law-1)*x/sbw + 1;

area = sum(longitudes1*tskn) + sum(longitudes2*tlr1) + sum(longitudes3*tlr2);
area = area*lws;

% Calcular las tensiones normales -----------------------------------------
Iy  = data.Esfuerzos.Inercias.Totales.Iy;
Iz  = data.Esfuerzos.Inercias.Totales.Iz;
Iyz = data.Esfuerzos.Inercias.Totales.Iyz;
Id  = data.Esfuerzos.Inercias.Totales.Id;

My  = data.Esfuerzos.Diagramas.My;
Mz  = data.Esfuerzos.Diagramas.Mz;
Nx  = data.Esfuerzos.Diagramas.Nx;

sigma_p1 = (My.*Iz + Mz.*Iyz)./Id;
sigma_p2 = (Mz.*Iy + My.*Iyz)./Id;

for i=1:1000
    lw = (law-1)/sbw*x(i) + 1; 
    tw = tor/sbw*x(i);
    
    z  = zpr*lw;
    y  = ypr*lw;

    y1 = cos(tw)*y + sin(tw)*z;
    z1 = cos(tw)*z - sin(tw)*y;

    sigma_p(:,i) = Nx(i)/area(i) + z1*sigma_p1(i) - y1*sigma_p2(i);
    yp(:,i) = y/lw;
    zp(:,i) = z/lw;
end

for i=1:1000
    lw = (law-1)/sbw*x(i) + 1; 
    tw = tor/sbw*x(i);

    z  = zl1*lw;
    y  = yl1*lw;

    y1 = cos(tw)*y + sin(tw)*z;
    z1 = cos(tw)*z - sin(tw)*y;

    sigma_l1(:,i) = Nx(i)/area(i) + z1*sigma_p1(i) - y1*sigma_p2(i);
    y1l(:,i) = y/lw;
    z1l(:,i) = z/lw;
end

for i=1:1000
    lw = (law-1)/sbw*x(i) + 1; 
    tw = tor/sbw*x(i);

    z  = zl2*lw;
    y  = yl2*lw;

    y1 = cos(tw)*y + sin(tw)*z;
    z1 = cos(tw)*z - sin(tw)*y;

    sigma_l2(:,i) = Nx(i)/area(i) + z1*sigma_p1(i) - y1*sigma_p2(i);
    y2l(:,i) = y/lw;
    z2l(:,i) = z/lw;
end

sigma.Piel.Tension = sigma_p;
sigma.Piel.Y = yp;
sigma.Piel.Z = zp;

sigma.Larguero1.Tension = sigma_l1;
sigma.Larguero1.Y = y1l;
sigma.Larguero1.Z = z1l;

sigma.Larguero2.Tension = sigma_l2;
sigma.Larguero2.Y = y2l;
sigma.Larguero2.Z = z2l;

data.Esfuerzos.Tensiones.sigma = sigma;

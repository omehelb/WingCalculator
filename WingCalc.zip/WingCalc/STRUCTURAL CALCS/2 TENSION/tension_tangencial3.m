function tau = tension_tangencial3(data)

% Importarlos datos del perfil --------------------------------------------
per = data.Dimensiones.Perfil;
pl1 = data.Interior.PosicionLarguero1;
pl2 = data.Interior.PosicionLarguero2;
crw = data.Dimensiones.CuerdaRaiz;
yG  = data.Esfuerzos.Centro_de_Gravedad.Y;
zG  = data.Esfuerzos.Centro_de_Gravedad.Z;

% Ajustar la posición de los largueros al formato 0.00 --------------------
pl1 = floor(100*pl1)/100;
pl2 = floor(100*pl2)/100;

% Importar datos del perfil y separar en extradós y entrados --------------
ptos  = load(['PERFILES\' per '.txt']);
ptos1 = ptos(1:101,:);
ptos2 = ptos(101:end,:);

% Aumentar la resolución del perfil ---------------------------------------
aup   = 2001;
ypin  = linspace(0,1,aup)';
ypex  = flip(ypin);

zpex  = interp1(ptos1(:,1),ptos1(:,2),ypex,'spline');
zpin  = interp1(ptos2(:,1),ptos2(:,2),ypin,'spline');

ptos1 = [ypex zpex];
ptos2 = [ypin(2:end) zpin(2:end)];

ptos  = [ptos1;ptos2];

% Ajustar la posición de los largueros ------------------------------------
pl1  = find(pl1>=ptos2(:,1));
pl1  = ptos2(pl1(end),1);
pl2  = find(pl2>=ptos2(:,1));
pl2  = ptos2(pl2(end),1);

% Posición vertical de los largueros --------------------------------------
psl11 = find(pl1==ptos(1:aup,1));
psl12 = find(pl1==ptos(aup:end,1)) + aup -1;

psl21 = find(pl2==ptos(1:aup,1));
psl22 = find(pl2==ptos(aup:end,1)) + aup -1;


%% TESNIÓN TANGENCIAL =====================================================
% Para el cálculo de este apartado se trabajará con 7 tramos de la sección
% del perfil:
%   - Tramo 1: Desde el borde de fuga hasta la parte superior del larguero
%     posterior.
%   - Tramo 2: Entre las partes superiores de los dos largueros.
%   - Tramo 3: Desde la parte superior del larguero delantero hasta la
%     parte inferior recorriendo el borde de ataque.
%   - Tramo 4: Entre las partes inferiores de los dos largueros.
%   - Tramo 5: Desde la parte inferior posterior hasta el borde de fuga
%   - Tramo 6: Larguero delantero.
%   - Tramo 7: Larguero posterior.

% Momentos estáticos ------------------------------------------------------
% Para hacer uso de la fórmula de flujo se ha de calcular antes que nada el
% moemnto estático. Este se hará iniciándolo a cero al incio del cada tramo
% descrito anteriormente. El sentido del flujo, con el borde de ataque a la
% izquierda será antihorario, siendo el de los largueros hacia abajo.

% Se recogen los puntos de las coordenadas de cada punto.
ptos  = [ptos1;ptos2]*crw - [yG zG];

y1 = ptos(1:psl21,1);
z1 = ptos(1:psl21,2);

y2 = ptos(psl21:psl11,1);
z2 = ptos(psl21:psl11,2);

y3 = ptos(psl11:psl12,1);
z3 = ptos(psl11:psl12,2);

y4 = ptos(psl12:psl22,1);
z4 = ptos(psl12:psl22,2);

y5 = ptos(psl22:end,1);
z5 = ptos(psl22:end,2);

y6 = linspace(pl1,pl1,101)'*crw - yG;
z6 = linspace(ptos(psl11,2),ptos(psl12,2),101)';

y7 = linspace(pl2,pl2,101)'*crw - yG;
z7 = linspace(ptos(psl21,2),ptos(psl22,2),101)';

% Se reorganizan las coordnadas en vectores de tramos, con punto incial,
% punto intermedio y punto final
tramo_1y = [y1(1:end-1) mean([y1(1:end-1),y1(2:end)]')' y1(2:end)];
tramo_1z = [z1(1:end-1) mean([z1(1:end-1),z1(2:end)]')' z1(2:end)];

tramo_2y = [y2(1:end-1) mean([y2(1:end-1),y2(2:end)]')' y2(2:end)];
tramo_2z = [z2(1:end-1) mean([z2(1:end-1),z2(2:end)]')' z2(2:end)];

tramo_3y = [y3(1:end-1) mean([y3(1:end-1),y3(2:end)]')' y3(2:end)];
tramo_3z = [z3(1:end-1) mean([z3(1:end-1),z3(2:end)]')' z3(2:end)];

tramo_4y = [y4(1:end-1) mean([y4(1:end-1),y4(2:end)]')' y4(2:end)];
tramo_4z = [z4(1:end-1) mean([z4(1:end-1),z4(2:end)]')' z4(2:end)];

tramo_5y = [y5(1:end-1) mean([y5(1:end-1),y5(2:end)]')' y5(2:end)];
tramo_5z = [z5(1:end-1) mean([z5(1:end-1),z5(2:end)]')' z5(2:end)];

tramo_6y = [y6(1:end-1) mean([y6(1:end-1),y6(2:end)]')' y6(2:end)];
tramo_6z = [z6(1:end-1) mean([z6(1:end-1),z6(2:end)]')' z6(2:end)];

tramo_7y = [y7(1:end-1) mean([y7(1:end-1),y7(2:end)]')' y7(2:end)];
tramo_7z = [z7(1:end-1) mean([z7(1:end-1),z7(2:end)]')' z7(2:end)];


% Se importan los espesores y se calculan longitudes
tskn = data.Dimensiones.EspesorPiel/1000;
tlr1 = data.Interior.EspesorLarguero1/1000;
tlr2 = data.Interior.EspesorLarguero2/1000;


longitudes = sqrt(diff([ptos(:,1)]).^2 + ...
                  diff([ptos(:,2)]).^2);
long1 = longitudes(1:psl21-1);
long2 = longitudes(psl21:psl11-1);
long3 = longitudes(psl11:psl12-1);
long4 = longitudes(psl12:psl22-1);
long5 = longitudes(psl22:end);
long6 = sqrt(diff(y6).^2 + diff(z6).^2);
long7 = sqrt(diff(y7).^2 + diff(z7).^2);


% Calcular momentos estáticos con el método de simpson. Hay que tener en
% cuenta que el perfil va cambiando con la envergadura estrechándolse y
% rotando. Se trabajará con matrices tridimensionales.

% Se recogen todos los vectores necesarios en variables de tipo celda.
tes = {tskn tskn tskn tskn tskn tlr1 tlr2};
longs = {long1 long2 long3 long4 long5 long6 long7};
tramosy = {tramo_1y tramo_2y tramo_3y tramo_4y tramo_5y tramo_6y tramo_7y};
tramosz = {tramo_1z tramo_2z tramo_3z tramo_4z tramo_5z tramo_6z tramo_7z};

% Se calcula en dos bucles for, uno por cada tramo y otro por cada punto de
% la envergadura rotando y reduciendo el perfil. Modificándolo también en
% base a si es una zona con costilla o no.

for j = 1:7

    yi = tramosy{j}(:,1);
    zi = tramosz{j}(:,1);

    ym = tramosy{j}(:,2);
    zm = tramosz{j}(:,2);

    yf = tramosy{j}(:,3);
    zf = tramosz{j}(:,3);

    slong = [zeros(size(longs{j})) longs{j}/2 longs{j}];

    mys{j} = tes{j} * (zi.*slong + (zf-zi)./longs{j}.*slong.^2/2);
    mzs{j} = tes{j} * (yi.*slong + (yf-yi)./longs{j}.*slong.^2/2);

     
    
end

% Se importan los refuerzos de los largueros independientemente de que
% existan o no, se considerarán para el cálculo del momento estático y el
% flujo con área nula o existente.

AcDS = data.Refuerzos.Cordones.Delantero_Superior(2);
AcDI = data.Refuerzos.Cordones.Delantero_Inferior(2);
AcPS = data.Refuerzos.Cordones.Posterior_Superior(2);
AcPI = data.Refuerzos.Cordones.Posterior_Inferior(2);

P_DS = [ptos(psl11,1);ptos(psl11,2)];
P_DI = [ptos(psl12,1);ptos(psl12,2)];
P_PS = [ptos(psl21,1);ptos(psl21,2)];
P_PI = [ptos(psl22,1);ptos(psl22,2)];

myDS = AcDS*P_DS(2);      mzDS = AcDS*P_DS(1);
myDI = AcDI*P_DI(2);      mzDI = AcDI*P_DI(1);
myPS = AcPS*P_PS(2);      mzPS = AcPS*P_PS(1);
myPI = AcPI*P_PI(2);      mzPI = AcPI*P_PI(1);

IyDS = AcDS*P_DS(2)^2;   IzDS = AcDS*P_DS(1)^2;
IyDI = AcDI*P_DI(2)^2;   IzDI = AcDI*P_DI(1)^2;
IyPS = AcPS*P_PS(2)^2;   IzPS = AcPS*P_PS(1)^2;
IyPI = AcPI*P_PI(2)^2;   IzPI = AcPI*P_PI(1)^2;

IyzDS = AcDS*P_DS(2)*P_DS(1);
IyzDI = AcDI*P_DI(2)*P_DI(1);
IyzPS = AcPS*P_PS(2)*P_PS(1);
IyzPI = AcPI*P_PI(2)*P_PI(1);


% Haciendo uso la fórmula general de cálculo de flujos se obtiene el flujo
% para un perfil abierto en cada uno de los tramos mencionados. Hay que
% tener en cuenta que, por ejemplo el tramo 5 inicia con los flujos finales
% de los tramos 4 y 7 y lo mismo con el tramo 4 que empieza con los flujos
% de los tramos 3 y 6.
Iy  = data.Esfuerzos.Inercias.Iy(2);
Iz  = data.Esfuerzos.Inercias.Iz(2);
Iyz = data.Esfuerzos.Inercias.Iyz(2);
Id  = data.Esfuerzos.Inercias.Id(2);

Qz = data.Esfuerzos.Diagramas.Qz(2);
Qy = data.Esfuerzos.Diagramas.Qy(2);

for j = [1 2 3 6 7 4 5]
    q0y = 0;
    q0z = 0;
    if j == 4
        q0y = squeeze(qsy{3}(end,end) + qsy{6}(end,end))' + ...
            1./Id.*((Qy.*IyzDI).*myDI - (Qy.*IyDI).*mzDI);
        q0z = squeeze(qsz{3}(end,end) + qsz{6}(end,end))' - ...
            1./Id.*((Qz.*IzDI).*myDI - (Qz.*IyzDI).*mzDI);
    elseif j == 5
        q0y = squeeze(qsy{4}(end,end) + qsy{7}(end,end))' + ...
            1./Id.*((Qy.*IyzPI).*myPI - (Qy.*IyPI).*mzPI);
        q0z = squeeze(qsz{4}(end,end) + qsz{7}(end,end,:))' - ...
            1./Id.*((Qz.*IzPI).*myPI - (Qz.*IyzPI).*mzPI);
    elseif j == 6
        q0y = squeeze(qsy{2}(end,end))' + ...
            1./Id.*((Qy.*IyzDS).*myDS - (Qy.*IyDS).*mzDS);
        q0z = squeeze(qsz{2}(end,end))' - ...
            1./Id.*((Qz.*IzDS).*myDS - (Qz.*IyzDS).*mzDS);
    elseif j == 7
        q0y = squeeze(qsy{1}(end,end))' + ...
            1./Id.*((Qy.*IyzPS).*myPS - (Qy.*IyPS).*mzPS);
        q0z = squeeze(qsz{1}(end,end))' - ...
            1./Id.*((Qz.*IzPS).*myPS - (Qz.*IyzPS).*mzPS);
    end

    size_rows = size(mys{j}(:,2),1);

    for i = 1:size_rows
        qsy{j}(i,1) = q0y + 1./Id.*((Qy.*Iyz).*squeeze(mys{j}(i,1))'...
             - (Qy.*Iy).*squeeze(mzs{j}(i,1))');
        qsy{j}(i,2) = q0y + 1./Id.*((Qy.*Iyz).*squeeze(mys{j}(i,2))'...
             - (Qy.*Iy).*squeeze(mzs{j}(i,2))');
        qsy{j}(i,3) = q0y + 1./Id.*((Qy.*Iyz).*squeeze(mys{j}(i,3))'...
             - (Qy.*Iy).*squeeze(mzs{j}(i,3))');

        qsz{j}(i,1) = q0z - 1./Id.*((Qz.*Iz).*squeeze(mys{j}(i,1))'...
             - (Qz.*Iyz).*squeeze(mzs{j}(i,1))');
        qsz{j}(i,2) = q0z - 1./Id.*((Qz.*Iz).*squeeze(mys{j}(i,2))'...
             - (Qz.*Iyz).*squeeze(mzs{j}(i,2))');
        qsz{j}(i,3) = q0z - 1./Id.*((Qz.*Iz).*squeeze(mys{j}(i,3))'...
             - (Qz.*Iyz).*squeeze(mzs{j}(i,3))');


        qs{j}(i,1) = qsy{j}(i,1) + qsz{j}(i,1);
        qs{j}(i,2) = qsy{j}(i,2) + qsz{j}(i,2);
        qs{j}(i,3) = qsy{j}(i,3) + qsz{j}(i,3);

        q0y = squeeze(qsy{j}(i,3))';
        q0z = squeeze(qsz{j}(i,3))';

         
        
    end
end

% Una vez calculados los flujos abiertos y comprobado tanto que en el borde
% de fuga, el flujo del tercer tramo se anula y que integrar el flujo en
% una dirrección resulta en el cortante hay que obtener el flujo cerrado
% haciendo uso de las fuerzas equivalentes.

for j = 1:7
    Feqy{j} = squeeze(longs{j}/6.*(qsy{j}(:,1) + 4*qsy{j}(:,2) + ...
        qsy{j}(:,3)));
    Feqz{j} = squeeze(longs{j}/6.*(qsz{j}(:,1) + 4*qsz{j}(:,2) + ...
        qsz{j}(:,3)));
    Feq{j}  = squeeze(longs{j}/6.*(qs{j}(:,1)  + 4*qs{j}(:,2)  + ...
        qs{j}(:,3)));
end

for j = 1:7
    ty1 = tramosy{j}(:,1);
    tz1 = tramosz{j}(:,1);

    ty2 = tramosy{j}(:,3);
    tz2 = tramosz{j}(:,3);

    b_palanca{j} = abs(squeeze((ty1.*tz2 - ty2.*tz1)./...
        sqrt((ty2 - ty1).^2 + (tz2 - tz1).^2)));

     
    
end

% Se procede a calcular las areas encerradas de cada una de las celdas.
Ac1 = polyarea([ptos(psl11:psl12,1)],...
               [ptos(psl11:psl12,2)]);
Ac2 = polyarea([ptos([psl21:psl11 psl12:psl22],1)],...
               [ptos([psl21:psl11 psl12:psl22],2)]);
Ac3 = polyarea([ptos([1:psl21 psl22:end],1)],...
               [ptos([1:psl21 psl22:end],2)]);

AcT = Ac1 + Ac2 + Ac3;

% Tras calcular las fuerzas equivalentes conviene hacer uso de la ecuación
% de giro equivalente donde el giro de las tres celdas es el mismo.

% Dado que la viga es de geometría variable las tensiones normales a la
% sección inducen torsiones por no estar alineadas con la sección.
sigma = tension_normal(data);

% Se aplica la, rotación,flecha, diedro y estrechamiento que sufren las
% secciones. Se calcula el área usando el espesor.

ypl = ptos(1:end-1,1);
yl1 = tramo_6y(:,2);
yl2 = tramo_6z(:,2);

zpl = ptos(1:end-1,2);
zl1 = tramo_7y(:,2);
zl2 = tramo_7y(:,2);

ply = ypl;
plz = zpl;

l1y = yl1;
l1z = zl1;

l2y = yl2;
l2z = zl2;

Apiel = tskn*[sqrt(diff(ply(1:2)).^2 + diff(plz(1:2))).^2;
    sqrt(diff(ply).^2 + diff(plz)).^2];

Alarg1(:,i) = [tlr1*sqrt(diff(l1y(1:2)).^2 + diff(l1z(1:2))).^2;
               tlr1*sqrt(diff(l1y).^2 + diff(l1z)).^2];

if AcDS ~= 0
    Alarg1(1) = AcDS;
elseif AcDI ~= 0
    Alarg1(end) = AcDI;
end

Alarg2 = [tlr2*sqrt(diff(l2y(1:2)).^2 + diff(l2z(1:2))).^2;
               tlr2*sqrt(diff(l2y).^2 + diff(l2z)).^2];

if AcPS ~= 0
    Alarg1(1,i) = AcPS;
elseif AcPI ~= 0
    Alarg1(end,i) = AcPI;
end


% Se hace uso de la equivalencia de momentos en cada punto de la
% envergaruda. Primero se calcular el momento generado por el cortante y se
% le añade el moemnto generado por el flujo, teniendo cuidado de que los
% largueros generen un momento positivo o negativo según su posición.
yCP = centro_presiones(data);

MM  = -Qz.*yCP(2) - sum(Feq{1}.*b_palanca{1}) - sum(Feq{2}.*b_palanca{2}) ...
    - sum(Feq{3}.*b_palanca{3}) - sum(Feq{4}.*b_palanca{4}) ...
    - sum(Feq{5}.*b_palanca{5});

if pl1*crw - yG <= 0
    MM = MM - sum(Feq{6}.*b_palanca{6});
else
    MM = MM + sum(Feq{6}.*b_palanca{6});
end

if pl2*crw - yG <= 0
    MM = MM - sum(Feq{7}.*b_palanca{7});
else
    MM = MM + sum(Feq{7}.*b_palanca{7});
end

% Con eso tenemos el término independiente de la ecuación de momentos,
% ahora se ha de usar la equivalencia de giros para obtener las otras dos
% ecuaciones necesarias.

% En primer lugar se calcula la estrechez δ de cada uno de los tramos,
% siendo δ1 el correspondiente a la celda del borde de ataque, δ2 la
% correspondiente a la central y δ3 la trasera. δ12 será la del larguero
% deltantero y δ23 la del trasero.

delta_1 = sum(long3)./tskn;
delta_2 = sum([long2;long4])./tskn;
delta_3 = sum([long1;long5])./tskn;

delta_12 = sum(long6)/tlr1;
delta_23 = sum(long7)/tlr2;

Feq_1 = Feq{3};
Feq_2 = [Feq{2}; Feq{4}];
Feq_3 = [Feq{1}; Feq{5}];
Feq_12 = Feq{6};
Feq_23 = Feq{7};

M1 = sum(Feq_1./tskn) - sum(Feq_12/tlr1);
M2 = sum(Feq_2./tskn) + sum(Feq_12/tlr1) - sum(Feq_23/tlr2);
M3 = sum(Feq_3./tskn) + sum(Feq_23/tlr2);

A = [2*Ac1, 2*Ac2, 2*Ac3
     delta_1+2*delta_12, -(delta_2+2*delta_12+delta_23), delta_23
     delta_12,           -(delta_2+delta_12+2*delta_23), delta_3+2*delta_23];
b = [MM;                   M2-M1;                        M2-M3];
q_constante = A\b;
 



tau_piel1 = (squeeze(qs{1}(:,2)) + q_constante(3))./tskn;
tau_piel2 = (squeeze(qs{2}(:,2)) + q_constante(2))./tskn;
tau_piel3 = (squeeze(qs{3}(:,2)) + q_constante(1))./tskn;
tau_piel4 = (squeeze(qs{4}(:,2)) + q_constante(2))./tskn;
tau_piel5 = (squeeze(qs{5}(:,2)) + q_constante(3))./tskn;
tau_piel  = [tau_piel1;tau_piel2;tau_piel3;tau_piel4;tau_piel5];

tau_lar1  = (squeeze(qs{6}(:,2)) - q_constante(1) + q_constante(2))/tlr1;
if sum(AcDS) ~= 0
    tau_lar1(1) = tau_lar1(1)*tlr1./(AcDS*1000/abs(y4(end)-y4(1)));
end
if sum(AcDI) ~= 0
    tau_lar1(end) = tau_lar1(end)*tlr1./(AcDI*1000/abs(y4(end)-y4(1)));
end

tau_lar2 = (squeeze(qs{7}(:,2)) - q_constante(2) + q_constante(3))/tlr2;
if AcPS ~= 0
    tau_lar2(1)   = tau_lar2(1)*tlr2./(AcPS*1000/abs(y5(end)-y5(1)));
end
if AcPI ~= 0
    tau_lar2(end) = tau_lar2(end)*tlr2./(AcPI*1000/abs(y5(end)-y5(1)));
end

% Para calcular el flujo constante debido a cortante su supondrá el
% cortante aplicado en el cec por lo cual no generará torsión. Se dividirá
% el cáculo en eje z y eje y para un posterior cálculo de la posición del
% cec.
Feq_y1 = Feqy{3};
Feq_z1 = Feqz{3};

Feq_y2 = [Feqy{2}; Feqy{4}];
Feq_z2 = [Feqz{2}; Feqz{4}];

Feq_y3 = [Feqy{1}; Feqy{5}];
Feq_z3 = [Feqz{1}; Feqz{5}];

Feq_y12 = Feqy{6};
Feq_z12 = Feqz{6};

Feq_y23 = Feqy{7};
Feq_z23 = Feqz{7};

M1y = sum(Feq_y1./tskn) - sum(Feq_y12/tlr1);
M1z = sum(Feq_z1./tskn) - sum(Feq_z12/tlr1);

M2y = sum(Feq_y2./tskn) + sum(Feq_y12/tlr1) - sum(Feq_y23/tlr2);
M2z = sum(Feq_z2./tskn) + sum(Feq_z12/tlr1) - sum(Feq_z23/tlr2);

M3y = sum(Feq_y3./tskn) + sum(Feq_y23/tlr2);
M3z = sum(Feq_z3./tskn) + sum(Feq_z23/tlr2);

A = [ delta_1+delta_12, -delta_12,                   0;
     -delta_12,          delta_2+delta_12+delta_23, -delta_23;
      0,                -delta_23,                   delta_3+delta_23];
by = [-M1y;-M2y;-M3y];
bz = [-M1z;-M2z;-M3z];
b  = [-M1; -M2; -M3];

q_constantececy = A\by;
q_constantececz = A\bz;
q_constantecec  = A\b;


tau_pielcec1 = (squeeze(qs{1}(:,2)) + q_constantecec(3))./tskn;
tau_pielcec2 = (squeeze(qs{2}(:,2)) + q_constantecec(2))./tskn;
tau_pielcec3 = (squeeze(qs{3}(:,2)) + q_constantecec(1))./tskn;
tau_pielcec4 = (squeeze(qs{4}(:,2)) + q_constantecec(2))./tskn;
tau_pielcec5 = (squeeze(qs{5}(:,2)) + q_constantecec(3))./tskn;
tau_pielcec  = [tau_pielcec1;tau_pielcec2;tau_pielcec3;tau_pielcec4;...
                tau_pielcec5];


tau_lar1cec = (squeeze(qs{6}(:,2)) - q_constantecec(1) + ...
              q_constantecec(2))/tlr1;
if AcDS ~= 0
    tau_lar1cec(1) = tau_lar1cec(1)*tlr1./(AcDS*1000/abs(y4(end)-y4(1)));
end
if AcDI ~= 0
    tau_lar1cec(end) = tau_lar1cec(end)*tlr1./(AcDI*1000/abs(y4(end)-y4(1)));
end


tau_lar2cec = (squeeze(qs{7}(:,2)) - q_constantecec(2) +  ...
              q_constantecec(3))/tlr2;
if AcPS ~= 0
    tau_lar2cec(1) = tau_lar2cec(1)*tlr2./(AcPS*1000/abs(y5(end)-y5(1)));
end
if AcPI ~= 0
    tau_lar2cec(end) = tau_lar2cec(end)*tlr2./(AcPI*1000/abs(y5(end)-y5(1)));
end

tau.Flujo_Completo.Piel.Tension = tau_piel;
tau.Flujo_Completo.Piel.Y       = ptos(2:end,1);
tau.Flujo_Completo.Piel.Z       = ptos(2:end,2);
tau.Flujo_Completo.Larguero1.Tension = tau_lar1;
tau.Flujo_Completo.Larguero1.Y       = tramo_6y(:,2);
tau.Flujo_Completo.Larguero1.Z       = tramo_6z(:,2);
tau.Flujo_Completo.Larguero2.Tension = tau_lar2;
tau.Flujo_Completo.Larguero2.Y       = tramo_7y(:,2);
tau.Flujo_Completo.Larguero2.Z       = tramo_7z(:,2);

tau.Flujo_Cortante.Piel.Tension = tau_pielcec;
tau.Flujo_Cortante.Piel.Y       = ptos(2:end,1);
tau.Flujo_Cortante.Piel.Z       = ptos(2:end,2);
tau.Flujo_Cortante.Larguero1.Tension = tau_lar1cec;
tau.Flujo_Cortante.Larguero1.Y       = tramo_6y(:,2);
tau.Flujo_Cortante.Larguero1.Z       = tramo_6z(:,2);
tau.Flujo_Cortante.Larguero2.Tension = tau_lar2cec;
tau.Flujo_Cortante.Larguero2.Y       = tramo_7y(:,2);
tau.Flujo_Cortante.Larguero2.Z       = tramo_7z(:,2);

tau.Flujo_Torsor.Piel.Tension = tau_piel - tau_pielcec;
tau.Flujo_Torsor.Piel.Y       = ptos(2:end,1);
tau.Flujo_Torsor.Piel.Z       = ptos(2:end,2);
tau.Flujo_Torsor.Larguero1.Tension = tau_lar1 - tau_lar1cec;
tau.Flujo_Torsor.Larguero1.Y       = tramo_6y(:,2);
tau.Flujo_Torsor.Larguero1.Z       = tramo_6z(:,2);
tau.Flujo_Torsor.Larguero2.Tension = tau_lar2 - tau_lar2cec;
tau.Flujo_Torsor.Larguero2.Y       = tramo_7y(:,2);
tau.Flujo_Torsor.Larguero2.Z       = tramo_7z(:,2);

% Cálculo del cec suponiendo que este se encuentra a la izquierda y encima
% del centro de gravedad

MMy  = 2*Ac1*q_constantececy(1) + 2*Ac2*q_constantececy(2) + ...
       2*Ac3*q_constantececy(3) + sum(Feqy{1}.*b_palanca{1}) + ...
       sum(Feqy{2}.*b_palanca{2}) + sum(Feqy{3}.*b_palanca{3}) + ...
       sum(Feqy{4}.*b_palanca{4}) + sum(Feqy{5}.*b_palanca{5});
MMz  = 2*Ac1*q_constantececz(1) + 2*Ac2*q_constantececz(2) + ...
       2*Ac3*q_constantececz(3) + sum(Feqz{1}.*b_palanca{1}) + ...
       sum(Feqz{2}.*b_palanca{2}) + sum(Feqz{3}.*b_palanca{3}) + ...
       sum(Feqz{4}.*b_palanca{4}) + sum(Feqz{5}.*b_palanca{5});

if pl1*crw - yG <= 0
    MMy = MMy + sum(Feqy{6}.*b_palanca{6});
    MMz = MMz + sum(Feqz{6}.*b_palanca{6});
else
    MMy = MMy - sum(Feqy{6}.*b_palanca{6});
    MMz = MMz - sum(Feqz{6}.*b_palanca{6});
end

if pl2*crw - yG <= 0
    MMy = MMy + sum(Feqy{7}.*b_palanca{7});
    MMz = MMz + sum(Feqz{7}.*b_palanca{7});
else
    MMy = MMy - sum(Feqy{7}.*b_palanca{7});
    MMz = MMz - sum(Feqz{7}.*b_palanca{7});
end

ez = -MMy./Qy;
ey =  MMz./Qz;

end

function yCP = centro_presiones(data)
% Se obtiene el centro de presiones para el cálculo de la torsión inducida.
% Se tendrá en cuenta únicamente la fuerza vertical puesto que el perfil es
% fino (y por tanto el brazo de palanca seraá mucho menor) y la fuerza
% horizonal es pequeña por lo cual el momento torsor inducido es también
% pequeño.

Cp  = data.Aerodinamica.Coeficientes.Cp;

x   = data.Aerodinamica.Coeficientes.Mx;
yG  = data.Esfuerzos.Centro_de_Gravedad.Y;
law = data.Dimensiones.Estrechamiento;
sbw = data.Dimensiones.Envergadura/2;
crw = data.Dimensiones.CuerdaRaiz;

xn  = data.Esfuerzos.Diagramas.x;

lws = (law-1)/sbw*xn + 1;

dx = diff(x);
dx = [dx(1,:); dx];
CMx = sum(Cp.*cumsum(dx).*dx);
CL  = sum(Cp.*dx);

yCP = interp1(1:length(CMx./CL),CMx./CL,linspace(1,length(CMx./CL),2000),...
    'spline');
yCP = yCP(1001:end) - yG*lws;
end

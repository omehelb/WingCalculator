function data = tension_normalRO(data)

% Importarlos datos del perfil --------------------------------------------
per = data.Dimensiones.Perfil;
pl1 = data.Interior.PosicionLarguero1;
pl2 = data.Interior.PosicionLarguero2;
crw = data.Interior.CuerdaRaiz_Nueva;
law = data.Interior.Estrechamiento_Nuevo;
tor = data.Dimensiones.Torsion*pi/180;
sbw = data.Interior.Envergadura_Nueva;
yG  = data.Esfuerzos.Centro_de_Gravedad.Y;
zG  = data.Esfuerzos.Centro_de_Gravedad.Z;
x   = data.Esfuerzos.Diagramas.x;

tskn = data.Dimensiones.EspesorPiel/1000;
tcos = data.Interior.EspesorCostillas/1000;
tlr1 = data.Interior.EspesorLarguero1/1000;
tlr2 = data.Interior.EspesorLarguero2/1000;

% Ajustar la posición de los largueros al formato 0.00 --------------------
pl1 = floor(100*pl1)/100;
pl2 = floor(100*pl2)/100;

% Importar datos del perfil y separar en extradós y entrados --------------
ptos  = load(['PERFILES\' per '.txt']);
ptos1 = ptos(1:101,:);
ptos2 = ptos(101:end,:);

% Posición vertical de los largueros --------------------------------------
psl11 = find(pl1==ptos1(:,1));
psl12 = find(pl1==ptos2(:,1));

psl21 = find(pl2==ptos1(:,1));
psl22 = find(pl2==ptos2(:,1));

% Aumentar la resolución del perfil ---------------------------------------
ypin  = -linspace(0,1,101)';
ypex  = flip(ypin);

zpex  = -interp1(ptos1(:,1),ptos1(:,2),-ypex,'spline');
zpin  = -interp1(ptos2(:,1),ptos2(:,2),-ypin,'spline');

ypra = [ypex; ypin(2:end)]*crw + yG;
zpra = [zpex; zpin(2:end)]*crw + zG;

ypr = (ypra(1:end-1) + ypra(2:end))/2;
zpr = (zpra(1:end-1) + zpra(2:end))/2;


% Aumentar la resolución de los largueros ---------------------------------
ylr1 = -pl1*ones(101,1)*crw + yG;
zlr1 = -linspace(ptos1(psl11,2),ptos2(psl12,2),101)'*crw + zG;

ylr2 = -pl2*ones(101,1)*crw + yG;
zlr2 = -linspace(ptos1(psl21,2),ptos2(psl22,2),101)'*crw + zG;

yl1 = (ylr1(1:end-1) + ylr1(2:end))/2;
zl1 = (zlr1(1:end-1) + zlr1(2:end))/2;

yl2 = (ylr2(1:end-1) + ylr2(2:end))/2;
zl2 = (zlr2(1:end-1) + zlr2(2:end))/2;


% Puntos de los extremos de los segmentos ---------------------------------
lws = (law-1)/sbw*x + 1;
tws = tor/sbw*x;

ypr_ex = lws.*(ypra*cos(tws) + zpra*sin(tws));
zpr_ex = lws.*(zpra*cos(tws) - ypra*sin(tws));

yl1_ex = lws.*(ylr1*cos(tws) + zlr1*sin(tws));
zl1_ex = lws.*(zlr1*cos(tws) - ylr1*sin(tws));

yl2_ex = lws.*(ylr2*cos(tws) + zlr2*sin(tws));
zl2_ex = lws.*(zlr2*cos(tws) - ylr2*sin(tws));


% Calcular longitudes -----------------------------------------------------
longskn = sqrt(diff(ptos(:,1)).^2 + diff(ptos(:,2)).^2)*lws;
longlr1 = sqrt(diff(ylr1).^2 + diff(zlr1).^2)*lws;
longlr2 = sqrt(diff(ylr2).^2 + diff(zlr2).^2)*lws;

% Cargar las inercias -----------------------------------------------------
Iy  = data.Esfuerzos.Inercias.Totales.Iy;
Iz  = data.Esfuerzos.Inercias.Totales.Iz;
Iyz = data.Esfuerzos.Inercias.Totales.Iyz;
Id  = data.Esfuerzos.Inercias.Totales.Id;

% Cargar las solicitaciones -----------------------------------------------
My  = data.Esfuerzos.Diagramas.My;
Mz  = data.Esfuerzos.Diagramas.Mz;
Nx  = data.Esfuerzos.Diagramas.Nx;

n_perf = length(x);

% Puntos de la envergadura con costilla -----------------------------------
nco  = data.Interior.NumeroCostillas;

xc   = linspace(0,sbw,nco)';
posc = zeros(size(xc));

for i = 1:length(xc)
    psc     = find(xc(i)>=x);
    posc(i) = psc(end);
end
posc = unique(posc);


% Cargar los materiales ---------------------------------------------------
Ecos = data.Materiales.Costillas.ModuloYoung;
mcos = data.Materiales.Costillas.Parametro_m;
c1cos = data.Materiales.Costillas.Fluencia/1e6;
fncos = data.Materiales.Costillas.Parametro_fn/1e6;

Eskn = data.Materiales.Piel.ModuloYoung;
mskn = data.Materiales.Piel.Parametro_m;
c1skn = data.Materiales.Piel.Fluencia/1e6;
fnskn = data.Materiales.Piel.Parametro_fn/1e6;

Elar = data.Materiales.Largueros.ModuloYoung;
mlar = data.Materiales.Largueros.Parametro_m;
c1lar = data.Materiales.Largueros.Fluencia/1e6;
fnlar = data.Materiales.Largueros.Parametro_fn/1e6;


% Cálcular tensiones por Ramberg-Osgood -----------------------------------
ep = 10.^(-6:.01:0);

fcos = RambergOsgood(ep,Ecos/1e6,fncos,mcos,c1cos)*1e6;
flar = RambergOsgood(ep,Elar/1e6,fnlar,mlar,c1lar)*1e6;
fskn = RambergOsgood(ep,Eskn/1e6,fnskn,mskn,c1skn)*1e6;


% Recoger todos los datos -------------------------------------------------
eps   = [-flip(ep(2:end)) ep];

sigcos = [-flip(fcos(2:end)') fcos'];
siglar = [-flip(flar(2:end)') flar'];
sigskn = [-flip(fskn(2:end)') fskn'];

yairf = [ypr; yl1; yl2];
zairf = [zpr; zl1; zl2];


% Calcular distancias a la linea neutra -----------------------------------
M  = sqrt(My.^2 + Mz.^2);

sigma1 = (My.*Iz + Mz.*Iyz)./Id;
sigma2 = (Mz.*Iy + My.*Iyz)./Id;
asigma = -sigma2./sigma1;

% sigma1y = (My.*Iz)./Id;
% sigma2y = (My.*Iyz)./Id;
% asigmay = -sigma2y./sigma1y;
% sigma1z = (Mz.*Iyz)./Id;
% sigma2z = (Mz.*Iy)./Id;
% asigmaz = -sigma2z./sigma1z;


% Parámetros auxiliares ---------------------------------------------------
yairf2 = lws.*(yairf*cos(tws) + zairf*sin(tws));
zairf2 = lws.*(zairf*cos(tws) - yairf*sin(tws));

ypr2 = lws.*(ypr*cos(tws) + zpr*sin(tws));
zpr2 = lws.*(zpr*cos(tws) - ypr*sin(tws));

yl12 = lws.*(yl1*cos(tws) + zl1*sin(tws));
zl12 = lws.*(zl1*cos(tws) - yl1*sin(tws));

yl22 = lws.*(yl2*cos(tws) + zl2*sin(tws));
zl22 = lws.*(zl2*cos(tws) - yl2*sin(tws));

dist    = (yairf2.*(sigma2./sigma1) + zairf2)/...
    sqrt((sigma2/sigma1).^2 + 1);

distskn = (ypr2.*(sigma2./sigma1) + zpr2)./...
    sqrt((sigma2./sigma1).^2 + 1);
distlr1 = (yl12.*(sigma2./sigma1) + zl12)./...
    sqrt((sigma2/sigma1).^2 + 1);
distlr2 = (yl22.*(sigma2./sigma1) + zl22)./...
    sqrt((sigma2/sigma1).^2 + 1);

dArho_skn = tskn*longskn.*abs(distskn);
dArho_cos = tcos*longskn.*abs(distskn);
dArho_lr1 = tlr1*longlr1.*abs(distlr1);
dArho_lr2 = tlr2*longlr2.*abs(distlr2);

epsilon_aprox = (sigma1(1)*zairf2(:,1) + sigma2(1)*yairf2(:,1))/Ecos;
[~,pos]       = max(epsilon_aprox);
kappa         = epsilon_aprox(pos)/dist(pos,1);

waitini = 0;
waitend = 1e3;

A_skn1 = longskn(:,1)*tskn;
A_lr11 = longlr1(:,1)*tlr1;
A_lr21 = longlr2(:,1)*tlr2;

b = -Nx(1)/(sum(A_skn1) + sum(A_lr11) + sum(A_lr21))/sigma1(1);

wait = waitbar(waitini/waitend,'Calculando solicitaciones...');

for i = 1:n_perf
    if i == floor(n_perf/100) 
        close(wait)
        wait = waitbar(waitini/waitend,'Calculando solicitaciones...');
    end

    err = 10;
    it = 1;
    a = asigma(i);

    y_air = yairf2(:,i);
    z_air = zairf2(:,i);

    A_skn = longskn(:,i)*tskn;
    A_cos = longskn(:,i)*tcos;
    A_lr1 = longlr1(:,i)*tlr1;
    A_lr2 = longlr2(:,i)*tlr2;
    errmax = 1*1e-10*1.05.^(1:5000) + .01;

    while and(err>errmax(it), it<5000)
       
        dist      = -(a*y_air - z_air + b)/sqrt(a.^2 + 1);

        epsilon   = kappa*dist;
        sig_skn   = interp1(eps,sigskn,epsilon(001:200));
        sig_lr1   = interp1(eps,siglar,epsilon(201:300));
        sig_lr2   = interp1(eps,siglar,epsilon(301:400));

        if ismember(i,posc)
            sig_cos = interp1(eps,sigcos,epsilon(001:200));
        else
            sig_cos  = zeros(size(sig_skn));
        end
        
        N_skn = sum(sig_skn.*A_skn);
        N_cos = sum(sig_cos.*A_cos);
        N_lr1 = sum(sig_lr1.*A_lr1);
        N_lr2 = sum(sig_lr2.*A_lr2);

        N_calc = N_skn + N_cos + N_lr1 + N_lr2;

        delta_b = 1e-5;
        dist_delN = -(a*y_air - z_air + (b + delta_b))/sqrt(a.^2 + 1);

        epsilon_delN   = kappa*dist_delN;
        sig_skn_delN   = interp1(eps,sigskn,epsilon_delN(001:200));
        sig_lr1_delN   = interp1(eps,siglar,epsilon_delN(201:300));
        sig_lr2_delN   = interp1(eps,siglar,epsilon_delN(301:400));

        if ismember(i,posc)
            sig_cos_delN = interp1(eps,sigcos,epsilon_delN(001:200));
        else
            sig_cos_delN  = zeros(size(sig_skn_delN));
        end
        
        N_skn_delN = sum(sig_skn_delN.*A_skn);
        N_cos_delN = sum(sig_cos_delN.*A_cos);
        N_lr1_delN = sum(sig_lr1_delN.*A_lr1);
        N_lr2_delN = sum(sig_lr2_delN.*A_lr2);

        N_calc_delN = N_skn_delN + N_cos_delN + N_lr1_delN + N_lr2_delN;
        
        dN_db = (N_calc_delN - N_calc) / delta_b;
        b = b - (N_calc - Nx(i)) / dN_db;

        errN = abs(N_calc - Nx(i)) / (abs(Nx(i)) + 20);


        if errN < errmax(it)
            dArho_skn = A_skn.*dist(001:200);
            dArho_cos = A_cos.*dist(001:200);
            dArho_lr1 = A_lr1.*dist(201:300);
            dArho_lr2 = A_lr2.*dist(301:400);
    
            M_skn = sum(sig_skn.*dArho_skn);
            M_cos = sum(sig_cos.*dArho_cos);
            M_lr1 = sum(sig_lr1.*dArho_lr1);
            M_lr2 = sum(sig_lr2.*dArho_lr2);
    
            M_calc = M_skn + M_cos + M_lr1 + M_lr2;
    
            delta_kappa   = 5e-5;
            if i > 998 
                delta_kappa = abs(Newkappa(i-1) - Newkappa(i-2));
            end
            epsilon_delta = (kappa + delta_kappa)*dist;
            sig_skn_delta = interp1(eps,sigskn,epsilon_delta(001:200));
            sig_lr1_delta = interp1(eps,siglar,epsilon_delta(201:300));
            sig_lr2_delta = interp1(eps,siglar,epsilon_delta(301:400));
            if ismember(i,posc)
                sig_cos_delta = interp1(eps,sigcos,epsilon_delta(001:200));
            else
                sig_cos_delta  = zeros(size(sig_skn_delta));
            end
    
            M_skn_delta = sum(sig_skn_delta.*dArho_skn);
            M_cos_delta = sum(sig_cos_delta.*dArho_cos);
            M_lr1_delta = sum(sig_lr1_delta.*dArho_lr2);
            M_lr2_delta = sum(sig_lr2_delta.*dArho_lr1);
    
            M_calc_delta = M_skn_delta + M_cos_delta + M_lr1_delta + M_lr2_delta;
    
            dM_dkappa = (M_calc_delta - M_calc) / delta_kappa;
            kappa = kappa - (M_calc - M(i)) / dM_dkappa;
    
            err = abs(M_calc - M(i)) / abs(M(i) + 50);
            
            if i>998
                disp(err)
            end

            if err < .015
                break
            end
        end
        it = it + 1;
        bbb(it) = errN;
        bba(it) = b;
    end
    bb(i) = b;
    Newkappa(i) = kappa;
    data.Esfuerzos.Tensiones.sigma.Piel.Tension(:,i) = sig_skn + sig_cos;
    data.Esfuerzos.Tensiones.sigma.Larguero1.Tension(:,i) = sig_lr1;
    data.Esfuerzos.Tensiones.sigma.Larguero2.Tension(:,i) = sig_lr2;

    sigmaskn(:,i) = sig_skn + sig_cos;
    sigmalr1(:,i) = sig_lr1;
    sigmalr2(:,i) = sig_lr2;

    waitini = waitini + 1;
    waitbar(waitini/waitend)
    itar(i) = it;

    if i == 998
        pause
    end

    distsknini = (a*ypr_ex(:,i) - zpr_ex(:,i) + b)/sqrt(a.^2 + 1);
    distlr1ini = (a*yl1_ex(:,i) - zl1_ex(:,i) + b)/sqrt(a.^2 + 1);
    distlr2ini = (a*yl2_ex(:,i) - zl2_ex(:,i) + b)/sqrt(a.^2 + 1);

    sigmasknini1 = interp1(dist(001:200),sig_skn + sig_cos,distsknini);
    sigmalr1ini1 = interp1(dist(201:300),sig_lr1,distlr1ini);
    sigmalr2ini1 = interp1(dist(301:400),sig_lr2,distlr2ini);

    vI1 = ~isnan(sigmasknini1); ind1 = 1:length(sigmasknini1);
    vI2 = ~isnan(sigmalr1ini1); ind2 = 1:length(sigmalr1ini1);
    vI3 = ~isnan(sigmalr2ini1); ind3 = 1:length(sigmalr2ini1);
    
    sigmasknini2 = sigmasknini1;
    sigmalr1ini2 = sigmalr1ini1;
    sigmalr2ini2 = sigmalr2ini1;

    sigmasknini2(~vI1) = interp1(ind1(vI1), sigmasknini1(vI1), ...
        ind1(~vI1), 'linear', 'extrap');
    sigmalr1ini2(~vI2) = interp1(ind2(vI2), sigmalr1ini1(vI2), ...
        ind2(~vI2), 'linear', 'extrap');
    sigmalr2ini2(~vI3) = interp1(ind3(vI3), sigmalr2ini1(vI3), ...
        ind3(~vI3), 'linear', 'extrap');

    sigmasknini(:,i) = sigmasknini2;
    sigmalr1ini(:,i) = sigmalr1ini2;
    sigmalr2ini(:,i) = sigmalr2ini2;
    disp(i)
end

close(wait)
giro = cumsum(Newkappa)*diff(x(1:2));
flecha   = cumsum(cumsum(Newkappa))*diff(x(1:2))^2;

data.Deformaciones.Curvatura   = Newkappa;
data.Deformaciones.Giro        = giro;
data.Deformaciones.Flecha      = flecha;
data.Deformaciones.Orientacion = atan2(My,Mz);

data.Esfuerzos.Tensiones.sigma.Piel.Tension = sigmaskn;
data.Esfuerzos.Tensiones.sigma.Piel.Y       = ypr*ones(1,n_perf);
data.Esfuerzos.Tensiones.sigma.Piel.Z       = zpr*ones(1,n_perf);

data.Esfuerzos.Tensiones.sigma.Larguero1.Tension = sigmalr1;
data.Esfuerzos.Tensiones.sigma.Larguero1.Y       = yl1*ones(1,n_perf);
data.Esfuerzos.Tensiones.sigma.Larguero1.Z       = yl1*ones(1,n_perf);

data.Esfuerzos.Tensiones.sigma.Larguero2.Tension = sigmalr2;
data.Esfuerzos.Tensiones.sigma.Larguero2.Y       = yl2*ones(1,n_perf);
data.Esfuerzos.Tensiones.sigma.Larguero2.Z       = zl2*ones(1,n_perf);


% Datos auxiliares para el cálculo de flujo tangencial --------------------
data.Esfuerzos.Tensiones.sigma.Piel.TensionExtremos      = sigmasknini;
data.Esfuerzos.Tensiones.sigma.Larguero1.TensionExtremos = sigmalr1ini;
data.Esfuerzos.Tensiones.sigma.Larguero2.TensionExtremos = sigmalr2ini;

save('..\MATLAB\saveddata.mat','data')
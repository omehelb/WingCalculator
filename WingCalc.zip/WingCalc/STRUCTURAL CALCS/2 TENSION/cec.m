function data = cec(data)


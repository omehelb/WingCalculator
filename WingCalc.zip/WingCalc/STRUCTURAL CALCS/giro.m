function data = giro(data)

% Importarlos datos del perfil --------------------------------------------
per = data.Dimensiones.Perfil;
pl1 = data.Interior.PosicionLarguero1;
pl2 = data.Interior.PosicionLarguero2;
crw = data.Interior.CuerdaRaiz_Nueva;
law = data.Interior.Estrechamiento_Nuevo;
tor = data.Dimensiones.Torsion*pi/180;
LLE = data.Dimensiones.FlechaLE*pi/180;
Did = data.Dimensiones.Diedro*pi/180;
sbw = data.Interior.Envergadura_Nueva;
yG  = data.Esfuerzos.Centro_de_Gravedad.Y;
zG  = data.Esfuerzos.Centro_de_Gravedad.Z;
nco = data.Interior.NumeroCostillas;
x   = data.Esfuerzos.Diagramas.x;
n_perf = length(x);

tskn = data.Dimensiones.EspesorPiel/1000;
tcos = data.Interior.EspesorCostillas/1000;
tlr1 = data.Interior.EspesorLarguero1/1000;
tlr2 = data.Interior.EspesorLarguero2/1000;

waitend = 2807;
waitini = 0;

% Ajustar la posición de los largueros al formato 0.00 --------------------
pl1 = floor(100*pl1)/100;
pl2 = floor(100*pl2)/100;

% Importar datos del perfil y separar en extradós y entrados --------------
ptos  = load(['PERFILES\' per '.txt']);
ptos(end,2) = 0;
ptos(1,2) = 0;

ptos1 = ptos(1:101,:);
ptos2 = ptos(101:end,:);

% Aumentar la resolución del perfil ---------------------------------------
ypin  = linspace(0,1,101)';
ypex  = flip(ypin);

zpex  = interp1(ptos1(:,1),ptos1(:,2),ypex,'spline');
zpin  = interp1(ptos2(:,1),ptos2(:,2),ypin,'spline');

ptos1 = [ypex zpex];
ptos2 = [ypin(2:end) zpin(2:end)];

ptos  = [ptos1;ptos2];

% Ajustar la posición de los largueros ------------------------------------
pl1  = find(pl1>=ptos2(:,1));
pl1  = ptos2(pl1(end),1);
pl2  = find(pl2>=ptos2(:,1));
pl2  = ptos2(pl2(end),1);

% Posición vertical de los largueros --------------------------------------
psl11 = find(pl1==ptos(1:101,1));
psl12 = find(pl1==ptos(101:end,1)) + 100;

psl21 = find(pl2==ptos(1:101,1));
psl22 = find(pl2==ptos(101:end,1)) + 100;

y6 = -linspace(pl1,pl1,101)'*crw + yG;
z6 = -linspace(ptos(psl11,2),ptos(psl12,2),101)';

y7 = -linspace(pl2,pl2,101)'*crw + yG;
z7 = -linspace(ptos(psl21,2),ptos(psl22,2),101)';


% Longitudes de cada segmento ---------------------------------------------
long_skn = sqrt(diff([ptos(:,1)]).^2 + diff([ptos(:,2)]).^2);
long_lr1 = sqrt(diff(y6).^2 + diff(z6).^2);
long_lr2 = sqrt(diff(y7).^2 + diff(z7).^2);


% Porcentaje que representa cada elemento en el área total ----------------
Area_skn = long_skn*tskn;
Area_lr1 = long_lr1*tlr1;
Area_lr2 = long_lr2*tlr2;

A_total  = sum(Area_skn) + sum(Area_lr1) + sum(Area_lr2);

por_skn  = Area_skn./A_total;
por_lr1  = Area_lr1./A_total;
por_lr2  = Area_lr2./A_total;


% Momento polar de inercia ------------------------------------------------
Iy = data.Esfuerzos.Inercias.Totales.Iy;
Iz = data.Esfuerzos.Inercias.Totales.Iz;

Jc = Iy + Iz;

data.Esfuerzos.Inercias.Polar.Jc = Jc;


% Módulo de Poisson -------------------------------------------------------
v_piel = .24;%data.Materiales.Piel.Poisson;
v_larg = .23;%data.Materiales.Largueros.Poisson;

m_piel = data.Materiales.Piel.Parametro_m;
m_larg = data.Materiales.Largueros.Parametro_m;

fn_piel = data.Materiales.Piel.Parametro_fn;
fn_larg = data.Materiales.Largueros.Parametro_fn;

E_piel = data.Materiales.Piel.ModuloYoung;
E_larg = data.Materiales.Largueros.ModuloYoung;

sig_skn = data.Esfuerzos.Tensiones.sigma.Piel.Tension;
sig_lr1 = data.Esfuerzos.Tensiones.sigma.Larguero1.Tension;
sig_lr2 = data.Esfuerzos.Tensiones.sigma.Larguero2.Tension;

poisson_skn = (v_piel + .5/m_piel*(sig_skn/fn_piel).^2)./(1 + ...
    1/m_piel*(sig_skn/fn_piel));
poisson_lr1 = (v_piel + .5/m_larg*(sig_lr1/fn_larg).^2)./(1 + ...
    1/m_larg*(sig_lr1/fn_larg));
poisson_lr2 = (v_piel + .5/m_larg*(sig_lr2/fn_larg).^2)./(1 + ...
    1/m_larg*(sig_lr2/fn_larg));


% Módulo de cortante ------------------------------------------------------
v_pois_skn = E_piel./2*(1+poisson_skn).*por_skn;
v_pois_lr1 = E_larg./2*(1+poisson_lr1).*por_lr1;
v_pois_lr2 = E_larg./2*(1+poisson_lr2).*por_lr2;

G_cort = sum(v_pois_skn) + sum(v_pois_lr1) + sum(v_pois_lr2);

data.Materiales.Modulo_Cortante = G_cort;


% Giro de torsion ---------------------------------------------------------
Tx = data.Esfuerzos.Diagramas.Tx;

theta = Tx./(G_cort.*Jc);

xc   = linspace(0,sbw,nco-1)';
posc = zeros(size(xc));

for i = 1:length(xc)
    psc     = find(xc(i)>=x);
    posc(i) = psc(end);
end
posc = unique(posc);

n_posc = floor((posc(1:end-1) + posc(2:end))/2);
thetan = theta(n_posc);

theta_n = interp1(n_posc,thetan,1:n_perf,'spline','extrap');

theta = theta_n - theta_n(1);

data.Deformaciones.Torsion = theta;
save('..\MATLAB\saveddata.mat','data')
for j = [1 4 5 2 3]
    q0 = zeros(size(x));
    if j == 2
        q0 = qs{1}(end,end,:) + qs{4}(end,end,:);
    elseif j == 3
        q0 = qs{2}(end,end,:) + qs{5}(end,end,:);
    end
    q0a = zeros(size(mys{j}(:,2,1)));
    for i = 1:n_perf 
        qs{j}(:,1,i) = q0(i) + q0a - 1/Id(i)*((Qz(i)*Iz(i)-Qy(i)*Iyz(i))* ...
            mys{j}(:,1,i) - (Qz(i)*Iyz(i)-Qy(i)*Iy(i))*...
            mzs{j}(:,1,i));
        qs{j}(:,2,i) = q0(i) + q0a - 1/Id(i)*((Qz(i)*Iz(i)-Qy(i)*Iyz(i))* ...
            mys{j}(:,2,i) - (Qz(i)*Iyz(i)-Qy(i)*Iy(i))*...
            mzs{j}(:,2,i));
        qs{j}(:,3,i) = q0(i) + q0a - 1/Id(i)*((Qz(i)*Iz(i)-Qy(i)*Iyz(i))* ...
            mys{j}(:,3,i) - (Qz(i)*Iyz(i)-Qy(i)*Iy(i))*...
            mzs{j}(:,3,i));
        q0a = qs{j}(:,3,i);
        waitini = waitini + 1;
        waitbar(waitini/waitend)
    end
end
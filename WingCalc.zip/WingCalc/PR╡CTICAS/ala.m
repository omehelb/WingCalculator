cwr = 13.45;
l   = 2.6/13.45;
LLE = 31.9;
bw  = 64.75;

Sw  = (cwr + l*cwr)*bw/4;
disp(Sw)
disp(bw^2/Sw)

x  = 0:.01:bw/2;

y1 = cwr - tan(LLE*pi/180)*x;
y2 = (2*cwr*(1-l)/bw - tan(LLE*pi/180))*x;

plot(x,y1,'k','LineWidth',2)
hold on
plot(-x,y1,'k','LineWidth',2)
plot(x,y2,'k','LineWidth',2)
plot(-x,y2,'k','LineWidth',2)
plot([bw/2 bw/2],[cwr*(1-l)-tan(LLE*pi/180)*bw/2,...
    cwr-tan(LLE*pi/180)*bw/2],'k','LineWidth',2)
plot([-bw/2 -bw/2],[cwr*(1-l)-tan(LLE*pi/180)*bw/2,...
    cwr-tan(LLE*pi/180)*bw/2],'k','LineWidth',2)
hold off
daspect([1 1 1])
axis([-1.1*bw/2 1.1*bw/2 -3*cwr 2*cwr])
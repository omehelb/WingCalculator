bw  = 64.8;
long = bw/2;

x = 0:.01:long;
q = -ones(size(x));

%% Sumatorio de fuerzas igual a cero

Dx = diff(x);
Dx = [Dx Dx(end)];

Qz = sum(q.*Dx);
My = Qz*long/2;

Qzx = -cumsum(q.*Dx);
Myx = cumsum(Qzx.*Dx);

figure(1)
subplot(1,3,1)
plot(x,q)
subplot(1,3,2)
plot(x,Qzx)
subplot(1,3,3)
plot(x,Myx)
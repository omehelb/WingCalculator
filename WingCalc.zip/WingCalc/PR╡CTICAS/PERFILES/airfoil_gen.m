%% PERFILES

NACA    = input('Introduce el perfil NACA de cuatro dígitos: ');
npoints = input('Introduce el número de puntos: ');

if NACA - floor(NACA) == 0 && numel(num2str(NACA)) == 4
mcp = .1*(floor(NACA/100)-10*floor(NACA/1000));
chm = floor(NACA/1000);
thk = NACA - 100*floor(NACA/100);

x1  = linspace(0,mcp/100,floor(mcp/100*npoints)+1);
x2  = linspace(x1(end)+1/npoints,1,100-floor(mcp/100*npoints));

yc1 = mcp/chm^2*(2*chm*x1-x1.^2);
yc2 = mcp/(1-chm)^2*(1 - 2*chm + 2*chm*x2 - x2.^2)+yc1(end);

plot([x1 x2],[yc1 yc2])
else
    if NACA - floor(NACA) == 0
        error('Tu número no tiene 4 dígitos')
    elseif numel(num2str(NACA)) == 4
        error('Tu número no debe tener decimales')
    else
        error('El número debe ser natural y de cuatro cifras')
    end
end

set(0,'defaulttextinterpreter','latex')
set(0,'DefaultTextFontSize',14)
set(0,'DefaultAxesFontSize',14)
set(0,'DefaultTextFontName','Times')
set(0,'DefaultAxesFontName','Times') 
set(0,'defaultlinelinewidth', 2)
% set(0,'defaultlinemarkersize',4);

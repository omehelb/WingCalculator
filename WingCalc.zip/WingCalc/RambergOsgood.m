function [f,iter,err,fep] = RambergOsgood(eps,young,fn,m,c1,c2)
% Función que calcula la tensión mediante Modelo Ramberg-Osgood de un
% vector de deformaciones eps . Se deben introducir los parámetros de 
% material (m, young, fn).
% La ecuación implicita se resuelve mediante mÃ©todo numérico Newton-Raphson

%Hallar un valor inicial mediante modelo aproximado (ESDU 73016. Sec 5)
k = 0.79044*m - 0.86977;
beta = (1+1/m)^(m-1-k) - (1+1/m)^-k;

fini = eps*young.*(1+beta*abs(eps*young/fn).^k + ...
    1/m*abs(eps*young/fn).^(m-1)).^(-1/m);

% Definición de función Ramberg-Osgood y derivada (ESDU 73016. Sec 3. Eq 3.1)
funcion1 = @(fi) eps*young/fn - fi / fn - 1/m * (fi / fn).^m; 
derfuncion1 = @(fi) - 1/fn * (1 + (fi / fn).^(m-1)); 

% Parámetros de mÃ©todo e inicialización de variables
itermax = 100;
tol = 1e-8;
iter = zeros(1,length(fini));
f = iter;

% Valores iniciales de método Newton-Raphson
fimagen = funcion1(fini);
fpimagen = derfuncion1(fini);
err = abs(fimagen);

while max(err) > tol && max(iter) < itermax

    % Se calcula el valor de f de la iteración siguiente (Newton-Raphson)
    iter(err>tol) = iter(err>tol) + 1;
    deltaf0 = fimagen ./ fpimagen;
    f(err>tol)  = fini(err>tol) - deltaf0(err>tol);
    
    % Nuevos cálculos iniciales
    fimagen = funcion1(f);
    fpimagen = derfuncion1(f);
    err = abs(fimagen);
    err = err(end,:);
    fini = f;
end

f=f';

% Elasto-pástico perfecto
fep=min(eps*young,c1);

% Grafica_RO(eps,f,young,fn,c1,c2)
end
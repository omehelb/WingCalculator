function y = Geom_dist(x0, x1, n, bias, sym)
% Es una fución que arroja una distribución de puntos "y" determinada por
% el número de puntos deseados, y el tipo de separación, simétrica, lineal,
% cuadrática...
%     x0: punto inicial
%     x1; punto final, > x0
%     n: número de nodos
%     bias: relacion entre el segmento fianl y el inicial (o central si
%       es simétrica), por defecto = 1 (lineal)
%     sym: distribución simétrica (true), o normal (false), por defecto
%       false
    
    % Valores por defecto. Si no se introduce la relación bias o sym, se
    % establece razón lineal normal (no simétrica).
    if not(exist('bias','var'))
        bias = 1;
    end
    if not(exist('sym','var'))
        sym = false;
    end
    
    % Cálculo de la razón geométrica. Este parámetro determina la
    % separación de los nodos, por si tiene que ser lineal, cuadrática...
    if sym
        r = bias^(1/(floor(n/2 - 1)));
    else
        r = bias^(1/(n-2));
    end
    
    % En la mayor parte de los casos r = 1 por lo cual la distribución será
    % equiespaciada.
    if r == 1
        % distribución lineal, si bias = 1
        Y = linspace(0,1,n);
    elseif not(sym)
        % homogeneamente creciente o decreciente si sym = false, r > 1.
        % Cuanto mayor sean n o r menor será d.
        Y = zeros(1,n);
        d = (1-r)/(1-r^(n-1));
        for i = 2:n
            Y(i) = Y(i-1)+d*r^(i-2);
        end
    else
        % Simétrica, si sym = true y bias ≠ 1. "d" es más o menos
        % similar al caso anterior aunque el ritmo de decrecimiento con r y
        % n es inferior. 
        Y = zeros(1,n);
        num = 1 - r;
        den = 2 - 2*r^((n-mod(n,2))/2) - mod(n+1,2)*(1 - r);
        d = num/den;
        for i = 2:n
            m = floor(abs(i - 1 - n/2));
            Y(i) = Y(i-1) + d*r^m;
        end
    end
    y = Y.*(x1-x0)+x0;
end
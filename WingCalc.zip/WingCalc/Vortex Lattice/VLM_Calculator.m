function data = VLM_Calculator(data)

%% VORTEX LATTICE METHOD

% VLM for a wing with sweep, taper, angle of attack and torsion
% The sweep can be modeled for a non sweep wing (straigth wing), bigger 
% than 0 (conventional sweep) or smaller than 0 (regresive sweep)

% Additionally, a control element can be set as a Flap or Aileron. Being
% the symmetric case the Flap and the antisymmetric case the Aileron

% Crespo Amor�s, Miguel - May 2018
% Last version - April 2019

%%

setPlot;

%% MAIN PARAMETERS

% Wing parameter definition

Wing.Parameters.Chord     = data.Dimensiones.CuerdaRaiz;
Wing.Parameters.AR        = data.Dimensiones.Esbeltez;
Wing.Parameters.Sweep     = data.Dimensiones.FlechaLE;
Wing.Parameters.Sweepr    = deg2rad(Wing.Parameters.Sweep);
Wing.Parameters.lambda    = data.Dimensiones.Estrechamiento;
Wing.Parameters.Sw        = data.Dimensiones.Envergadura*...
    data.Dimensiones.CuerdaRaiz*(1 + data.Dimensiones.Estrechamiento)/2;
Wing.Parameters.b         = data.Dimensiones.Envergadura;
Wing.Parameters.dihedral  = data.Dimensiones.Diedro;
Wing.Parameters.dihedralr = deg2rad(Wing.Parameters.dihedral);

Wing.Parameters.xoffset   = 0;            
Wing.Parameters.yoffset   = 0;            
Wing.Parameters.zoffset   = 0;

Wing.Parameters.prof_R  = data.Dimensiones.Perfil(6:end);
Wing.Parameters.prof_T  = data.Dimensiones.Perfil(6:end);
Wing.Parameters.PF      = 'trap';
Wing.Parameters.tor_d   = 0;%-0.25;
Wing.Parameters.theta0  = data.Dimensiones.Torsion;
Wing.Parameters.theta0r = deg2rad(Wing.Parameters.theta0);
Wing.Parameters.tor     = @(y) Wing.Parameters.theta0r*(2*abs(y/Wing.Parameters.b));

Wing.Parameters.Nc      = data.Aerodinamica.PanelesY;
Wing.Parameters.nx      = Wing.Parameters.Nc+1;
Wing.Parameters.Nss     = data.Aerodinamica.PanelesX;
Wing.Parameters.ny      = Wing.Parameters.Nss*2+1;
Wing.Parameters.Nt      = Wing.Parameters.Nc*Wing.Parameters.Nss*2;
Wing.Parameters.bias_x  = 1;
Wing.Parameters.bias_y  = 1;

% Flight Conditions

FC.aoa     = data.Aerodinamica.AoA;
FC.aoar    = deg2rad(FC.aoa);
FC.beta    = 0;
FC.betar   = deg2rad(FC.beta);
FC.H       = data.Aerodinamica.Altitud;
[T,a,P,rho]= atmosisa(FC.H);
FC.U       = data.Aerodinamica.Velocidad;
FC.M       = FC.U/a;
FC.q       = 0.5*rho*FC.U^2;
FC.naoa    = size(FC.aoar,2);

%% Wing Generation

casetype   = 'Standard';

[Wing]     = GenerateWing(Wing);

switch casetype
    
    case 'Standard'
        
        
        [Wing]     = GenerateMesh(Wing);
        DisplayCase(Wing,FC);
        [data]     = VortexLattice(Wing,FC,data);

    case 'Symmetric'

        [Wing]     = GenerateSymMesh(Wing,Flap);
        surf(Wing.Mesh.X,Wing.Mesh.Y,Wing.Mesh.Z);
        axis equal
        Wing.Parameters.Nc  = Flap.Parameters.Nc+Flap.Parameters.Nf;
        Wing.Parameters.Nss = Flap.Parameters.Ns1+Flap.Parameters.Nsf+Flap.Parameters.Ns3;
        Wing.Parameters.Nt  = Wing.Parameters.Nc*Wing.Parameters.Nss*2;

        [Wing]     = VortexLattice(Wing,FC);
        
    case 'AntiSymmetric'

        [Wing]     = GenerateAntMesh(Wing,Flap);
        surf(Wing.Mesh.X,Wing.Mesh.Y,Wing.Mesh.Z);
        axis equal
        Wing.Parameters.Nc  = Flap.Parameters.Nc+Flap.Parameters.Nf;
        Wing.Parameters.Nss = Flap.Parameters.Ns1+Flap.Parameters.Nsf+Flap.Parameters.Ns3;
        Wing.Parameters.Nt  = Wing.Parameters.Nc*Wing.Parameters.Nss*2;

        [Wing]     = VortexLattice(Wing,FC);
            
end
            mys{j}(k,1,i) = 0;
            mys{j}(k,2,i) = ts*longs{j}(k)/12.*(zi(k) + ...
                4*mean([zm(k),zi(k)]')' + zm(k));
            mys{j}(k,3,i) = ts*longs{j}(k)/6.*(zi(k) + 4*zm(k) + zf(k));

            mzs{j}(k,1,i) = 0;
            mzs{j}(k,2,i) = ts*longs{j}(k)/12.*(yi(k) + ...
                4*mean([ym(k),yi(k)]')' + ym(k));
            mzs{j}(k,3,i) = ts*longs{j}(k)/6.*(yi(k) + 4*ym(k) + yf(k));
            
        end
        waitini = waitini + 1;
        waitbar(waitini/waitend)
    end
end


            slong = [0 longs{j}(k)/2 longs{j}(k)];
            
            mys{j}(k,:,i) = ts*(zi(k)*slong +...
                (zf(k)-zi(k))/longs{j}(k).*slong.^2/2);

            mzs{j}(k,:,i) = ts*(yi(k)*slong +...
                (yf(k)-yi(k))/longs{j}(k).*slong.^2/2);
            
        end
        waitini = waitini + 1;
        waitbar(waitini/waitend)
    end
end